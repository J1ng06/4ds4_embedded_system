// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

// This is the embedded software for the
// LCD / Camera design

#include "define.h"

// read a 4-byte little endian int from the SD card with error checking
bool sd_card_read_int (short int file_handle, int *data) {
    unsigned short int read_data;

    *data = 0;
    if (((read_data = sd_card_read(file_handle)) >> 8) != 0) return false;
    *data |= read_data;
    if (((read_data = sd_card_read(file_handle)) >> 8) != 0) return false;
    *data |= read_data << 8;
    if (((read_data = sd_card_read(file_handle)) >> 8) != 0) return false;
    *data |= read_data << 16;
    if (((read_data = sd_card_read(file_handle)) >> 8) != 0) return false;
    *data |= read_data << 24;

    return true;
}

// This function parses the bitmap header.  It is more sophisticated than for
// the PPM header because it must extract the image width and height and it does
// some error checking to make sure it is a valid BMP file.  Also, it must be
// able to handle the variable header length
bool parse_BMP_header (short int file_handle, BMP_size *image_size) {
    int offset, i;
    bool status;

    // check magic number
    if (sd_card_read(file_handle) != 'B') status = false;
    if (sd_card_read(file_handle) != 'M') status = false;
    for (i = 2; i < 10; i++) { // strip next 8 bytes of header
        if ((sd_card_read(file_handle) >> 8) != 0) return false; 
    }

    // get offset to image data
    if (!sd_card_read_int(file_handle, &offset)) return false;

    for (i = 14; i < 18; i++) // strip next 4 bytes
        if ((sd_card_read(file_handle) >> 8) != 0) return false; 

    if (!sd_card_read_int(file_handle, &(image_size->width))) return false;
    if (!sd_card_read_int(file_handle, &(image_size->height))) return false;
    
    for (i = 26; i < offset; i++) // trash the rest of the header
        if ((sd_card_read(file_handle) >> 8) != 0) return false; 

    return true;
}

int main() 
{
    // alt_up_sd_card_dev *sd_card_dev = NULL;
    PB_irq_data_struct PB_irq_data;
    short int file_handle;
    int i, j;
    int connected = 0;
    int status;
    unsigned short int data;
    char filename[13];
    int file_number = 0;
    BMP_size image_size;
    const unsigned char default_header[] = { 
	    0x42, 0x4d, 0x36, 0x10, 0x0e, 0x00, 0x00, 0x00, 0x00, 0x00, 
	    0x36, 0x00, 0x00, 0x00, 0x28, 0x00, 0x00, 0x00, 
	    0x40, 0x01, 0x00, 0x00, 0x10, 0xff, 0xff, 0xff, // note the image size has been changed to 320x240 
	    0x01, 0x00, 0x18, 0x00, 0x00, 0x00, 0x00, 0x00, 
	    0x00, 0x10, 0x0e, 0x00, 0x13, 0x0b, 0x00, 0x00, 
	    0x13, 0x0b, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	    0x00, 0x00, 0x00, 0x00 };
    // these buffers are capable of storing a full line (unlike R_vals, G_vals, B_vals which only store half a line)
    // I used these so I wouldn't have to tinker with the the LTC_Write_Line/Read_Line functions
    // because if you modify those functions, this code can never be used for anything other than 320x240
    alt_u8 R_buf[LINE_LEN], G_buf[LINE_LEN], B_buf[LINE_LEN];
    
    printf("Experiment 3!\n");

    PB_irq_data.load_img_flag = 0;
    PB_irq_data.save_img_flag = 0;
    
    // sd_card_dev = alt_up_sd_card_open_dev("/dev/SD_card_0");
    sd_card_open_dev();
    
    alt_irq_register(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_IRQ, NULL, (void *)LTC_TouchPanel_int);
    init_button_irq(&PB_irq_data);
    

    // initialize the touch panel
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 2, 0x0);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 1, 0x400000);

    // initialize the camera
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 0, 0x0400);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x2);
    while ((IORD(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1) & 0x1) == 0);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x4);

    // initialize the buttons
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 1, 0x0);
    
    // initialize the filter pipe
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_IMAGELINE_BASE, 4, 0);

        while(1) { 
            if ((connected == 0) && (sd_card_is_Present())) {
                printf("Card connected.\n"); 
                connected = 1; 
                if (sd_card_is_FAT16()) {
                    printf("Valid file system detected.\n"); 
                } else {
                    printf("Unknown file system.\n");
                }
                status = sd_card_find_first(".", PB_irq_data.filename);
                
                switch (status) {
                    case 0: printf("Success\n"); break;
                    case 1: printf("Invalid directory\n"); break;
                    case 2: printf("No card or incorrect FS\n"); break;
                }
            } else if ((connected == 1) && (sd_card_is_Present() == false)) {
                printf("Card disconnected.\n"); connected = 0;
            }
            
            if (PB_irq_data.load_img_flag == 1) {
                // stop the camera
                IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x8);
                
                file_handle = sd_card_fopen(PB_irq_data.filename, false);
                
                if (status < 0) printf("Error opening file \"%s\"\n", PB_irq_data.filename);
                else {
                    printf("Loading image data from file \"%s\"\n", PB_irq_data.filename);

		    // parse BMP header
		    if (!parse_BMP_header(file_handle,&image_size))
			    printf("Error reading BMP header... wrong format or corrupted file!  Aborting\n");
		    else if (((image_size.height != 240) && (image_size.height != -240)) || (image_size.width != 320))
			    printf("Wrong image size! Aborting\n");
		    else {
                printf("Image is %s\n",(image_size.height > 0) ? "inverted" : "not inverted");
                        LTC_Switch_Nios_Mode(1);

                        // Top region
                        for (i = 0; i < LINE_LEN; i++)
                            R_buf[i] = G_buf[i] = B_buf[i] = 0;
                        for (i = 0; i < NUM_LINES/4; i++)
                            LTC_Write_Image_Line(R_buf,G_buf,B_buf);
                        
                        // READ IMAGE FROM CARD AND DISPLAY
                        for (i = 0; i < NUM_LINES/2; i++) {
                            IOWR(LED_RED_O_BASE, 0, i);  // Red LEDs now show current row - just to speed things up a touch
                            for (j = 0; j < LINE_LEN/2; j++) {
                                data = sd_card_read(file_handle);
                                if ((data >> 8) != 0) printf("B eof reached: %d, %d\n", i, j);
                                // if the image is not inverted put it in the buffer to be written to screen
                                if (image_size.height < 0) B_buf[j + LINE_LEN/4] = data & 0xff;
                                // otherwise, if it is inverted, we have to buffer the entire image
                                else B_vals[i][j] = data & 0xFF;

                                data = sd_card_read(file_handle);
                                if ((data >> 8) != 0) printf("G eof reached: %d, %d\n", i, j);
                                if (image_size.height < 0) G_buf[j + LINE_LEN/4] = data & 0xff;
                                else G_vals[i][j] = data & 0xFF;

                                data = sd_card_read(file_handle);
                                if ((data >> 8) != 0) printf("R eof reached: %d, %d\n", i, j);
                                if (image_size.height < 0) R_buf[j + LINE_LEN/4] = data & 0xff;
                                else R_vals[i][j] = data & 0xFF;
                            }                        
                            if (image_size.height < 0) LTC_Write_Image_Line(R_buf, G_buf, B_buf);
                        }                                       
			
    		            // if the image is inverted
                        if (image_size.height > 0) 
                            for (i = NUM_LINES/2 - 1; i >= 0; i--) {
                               for (j = 0; j < LINE_LEN/2; j++) {
                                  R_buf[j + LINE_LEN/4] = R_vals[i][j]; 
                                  G_buf[j + LINE_LEN/4] = G_vals[i][j]; 
                                  B_buf[j + LINE_LEN/4] = B_vals[i][j]; 
                               }
                               LTC_Write_Image_Line(R_buf, G_buf, B_buf);
    			            }
                        // END READ IMAGE FROM CARD AND DISPLAY
                        
                        // Bottom region
                        for (i = 0; i < LINE_LEN; i++)
                            R_buf[i] = G_buf[i] = B_buf[i] = 0;
                        for (i = 0; i < NUM_LINES/4; i++)
                            LTC_Write_Image_Line(R_buf,G_buf,B_buf);

                        LTC_Switch_HW_Mode();
		    }

                    sd_card_fclose(file_handle);

                }
                
                PB_irq_data.load_img_flag = 0;
            }
            
            if (PB_irq_data.save_img_flag == 1) {
                // stop the camera
                IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x8);
                
                sprintf(filename, "file%d.bmp", file_number++);
                
                while ((file_handle = sd_card_fopen(filename, 1)) < 0) {
                    sprintf(filename, "file%d.bmp", file_number++);                 
                }
                
                printf("Saving image to file (%s)...\n", filename);
                LTC_Switch_Nios_Mode(0);

                // BMP header
				for (i = 0, status = true; i < 54; i++)
					status = status && sd_card_write(file_handle, default_header[i]);
				if (!status) printf("Write fail in header!\n");

				// Note some subtle issues here:
				//   1) the number of LTC_Read_Image_Line commands is still 480 - every even line is just discarded
				//   2) the order in which the colours is written is now BGR, not RGB
				//   3) the spec calls to discard ODD rows and columns
                for (i = 0; i < NUM_LINES / 2; i++) {
                    IOWR(LED_RED_O_BASE, 0, i);  // Red LEDs now show current row - just to speed things up a touch
                    LTC_Read_Image_Line(R_buf, G_buf, B_buf);
                    for (j = 0; j < LINE_LEN; j+=2) {
                        status = sd_card_write(file_handle, B_buf[j]);
                        if (!status) printf("Write fail: B %d %d\n", i, j);
                        status = sd_card_write(file_handle, G_buf[j]);
                        if (!status) printf("Write fail: G %d %d\n", i, j);
                        status = sd_card_write(file_handle, R_buf[j]);
                        if (!status) printf("Write fail: R %d %d\n", i, j);
                    }
                    LTC_Read_Image_Line(R_buf, G_buf, B_buf); // discard odd rows
                }                                       
                
                LTC_Switch_HW_Mode();

                sd_card_fclose(file_handle);
		        printf("Write complete\n");

                PB_irq_data.save_img_flag = 0;
            }
        }
    
    return 0;
}
