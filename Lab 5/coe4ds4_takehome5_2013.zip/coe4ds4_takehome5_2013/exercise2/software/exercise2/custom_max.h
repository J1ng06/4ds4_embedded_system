// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#ifndef __CUSTOM_COUNTER_H__
#define __CUSTOM_COUNTER_H__

// Reading and writing elements from the array - it's a bit quicker to do this through defines
#define WRITE_ELEMENT(BASE, ADDR, DATA) \
	IOWR((BASE), 0, ((1 << 24) | (((ADDR) & 0xff) << 16) | ((DATA) & 0xffff)))

#define READ_ELEMENT(BASE, ADDR, RESULT) \
	IOWR((BASE), 0, (((ADDR) & 0xff) << 16)); RESULT = IORD((BASE), 1)

// Global functions
void handle_result_available_interrupts();
void find_max();
void init_max_irq();

#endif
