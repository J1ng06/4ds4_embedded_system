// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

int main()
{
    int array[256];
    int i, idx, temp;
    
	printf("Start main...\n");

	IOWR(LED_GREEN_O_BASE, 0, 0x0);
	IOWR(LED_RED_O_BASE, 0, 0x0);

    // I didn't use the PBs but it's good to have them for experimentation/debug
	init_button_irq();
	printf("PB initialized...\n");
	
	init_max_irq();
	printf("Max finder IRQ initialized...\n");
	printf("System is up!\n");

	IOWR(LED_RED_O_BASE, 0, 0xF);
		
    printf("Generating test values... ");
    for (i = 0; i < 256; i++) array[i] = rand() & 0xffff;
    printf("done!\n");
    
    printf("Writing test values to module... ");
    for (i = 0; i < 256; i++) WRITE_ELEMENT(CUSTOM_MAX_COMPONENT_0_BASE,i,array[i]);
    printf("done!\n");
    
    printf("Reading test values back to verify... ");
    for (i = 0; i < 256; i++) {
        // The array values are scanned back out-of-order because
        // this is a more thorough test
        idx = ((i & 0xf) << 4) | ((i & 0xf0) >> 4);
        READ_ELEMENT(CUSTOM_MAX_COMPONENT_0_BASE,idx,temp); 
        if (temp != array[idx]) { // if we have a mismatch, just bail out
            printf("Mismatch at element 0x%x!!!\n",idx);
            return -1;
        }
    }
    printf("done!\n"); // if we got here, we read everything correctly
  
    // start the max finding and the result is printed by the isr
    printf("Finding max... ");
    find_max(); 
    
    // Verify max result with software
    temp = 0;
    for (i = 0; i < 256; i++) if (temp < array[i]) temp = array[i];
    printf("Software verifies max value to be %d\n",temp);

    while(1);
	
	return 0;
}
