#ifndef __CUSTOM_COMPONENT_H__
#define __CUSTOM_COMPONENT_H__

// Global functions
void handle_result_available_interrupts();
void start_search();
void init_search_irq();

#endif
