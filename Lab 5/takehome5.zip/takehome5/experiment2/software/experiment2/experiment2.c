// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

int main()
{
	short int array[256];
	int i;
	short int temp,temp1;
	int sum;
	printf("Start main...\n");

	IOWR(LED_GREEN_O_BASE, 0, 0x0);
	IOWR(LED_RED_O_BASE, 0, 0x0);

	init_button_irq();
	printf("PB initialized...\n");
	
	init_counter_irq();
	printf("Counter IRQ initialized...\n");
	
	printf("System is up!\n");

	init_search_irq();
	printf("Max finder IRQ initialized...\n");
	printf("System is up!\n");

	IOWR(LED_RED_O_BASE, 0, 0xF);
		
    printf("Generating test values... \n");
    for (i = 0; i < 256; i++) {array[i] = rand() & 0xffff; printf("value %d is %d\n",i,array[i]);}
    printf("done!\n");

    printf("Writing test values to module... ");
    for (i = 0; i < 256; i++) IOWR((CUSTOM_COMPONENT_0_BASE), 0, ((1 << 24) | (((i) & 0xff) << 16) | ((array[i]) & 0xffff)));
    printf("done!\n");


    // start the max finding and the result is printed by the isr
    printf("Searching max... \n");
    start_search();

    // Verify max result with software
    temp = 0x8000;
    temp1 = 0x7fff;
    sum = 0;
    for (i = 0; i < 256; i++) {
    	if (temp < array[i]) temp = array[i];
    	if (temp1 > array[i]) temp1 = array[i];
    	sum += array[i];
    }
    printf("Software verifies max value to be %d\n",temp);
    printf("Software verifies min value to be %d\n",temp1);
    printf("Software verifies sum value to be %d\n",sum/256);

    while(1);
	
	return 0;
}
