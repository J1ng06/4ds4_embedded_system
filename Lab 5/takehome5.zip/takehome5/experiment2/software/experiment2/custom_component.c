#include "define.h"

// ISR when the counter is expired
void handle_result_available_interrupts()
{
	printf("Max value of %d found\n",IORD(CUSTOM_COMPONENT_0_BASE, 2));
	printf("Min value of %d found\n",IORD(CUSTOM_COMPONENT_0_BASE, 3));

	IOWR(CUSTOM_COMPONENT_0_BASE, 6, 0); // clear interrupt
}

void start_search()
{
	// create a positive edge at offset 5 to start the max finding circuitry
	IOWR(CUSTOM_COMPONENT_0_BASE, 5, 0);
	IOWR(CUSTOM_COMPONENT_0_BASE, 5, 1);
}

// Function for initializing the ISR of the Counter
void init_search_irq() {
	IOWR(CUSTOM_COMPONENT_0_BASE, 6, 0);


	alt_irq_register(CUSTOM_COMPONENT_0_BASE, NULL, (void*)handle_result_available_interrupts );
}
