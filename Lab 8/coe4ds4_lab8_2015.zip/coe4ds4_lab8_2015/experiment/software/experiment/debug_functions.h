// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#ifndef __debug_function_H__
#define __debug_function_H__

#define CC_DONE_TIMEOUT 1000

#define RAM_SIZE 4096

// Global functions
void custom_SD_queue_write(char *, int);
void custom_SD_new_logfile();

void debug_get_image();
void debug_fill_search_ram(int);
void debug_fill_reference_ram(int);
void debug_read_search_ram(int);
void debug_read_reference_ram(int);
void debug_read_sinc_rom(int);
void debug_read_work1_ram(int, int, int);
void debug_read_work2_ram(int, int, int);
void debug_dma(int, int);
void debug_full_flow();
void debug_correlation_flow();
void debug_fft_offset();

#endif
