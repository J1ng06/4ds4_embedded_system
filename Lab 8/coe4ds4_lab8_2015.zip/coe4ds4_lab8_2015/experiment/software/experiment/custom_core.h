// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#ifndef __custom_core_H__
#define __custom_core_H__

// Global functions
void handle_done_interrupts();
void init_done_isr();
void init_TPChange_isr();
void handle_TPChange_interrupts();
void custom_core_task(void*);

#endif
