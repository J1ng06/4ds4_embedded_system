// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#ifndef __task_H__
#define __task_H__

// Size of stack for each task
#define	  TASK_STACKSIZE	   2048

// Definition of Task Priorities
#define INITIALIZE_TASK_PRIORITY    6

#define SD_MUTEX_PRIORITY               10
#define SD_PRESENCE_DETECT_PRIORITY     11

#define CUSTOM_CORE_TASK_PRIORITY 		12
#define SD_WRITE_PRIORITY               13

#define TASK_START_PRIORITY		 		14

//#define SD_READ_PRIORITY                12
//#define COMPUTE_Y_PRIORITY              13
//#define PROCESS_Y_PRIORITY              14
//#define CUSTOM_TASK_0_PRIORITY	  17

#define TASK_LAUNCHER_PRIORITY    17


// Global function
void task_launcher(void *pdata);

#endif
