// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

extern OS_EVENT *TPChangeSemaphore;
extern alt_up_character_lcd_dev *lcd_0;

int exposure, run;
int config;

int tracked_x, tracked_y;
int cur_s_xval;
int cur_s_yval;
int box_flag;
int TouchXVal, TouchYVal, TouchXYFlag;

void TouchPanel_int(void) {
    int TP_val, x_val, y_val, key = 6;
    INT8U return_code = OS_NO_ERR;
	char Text[16];

	OSIntEnter();
	
    TP_val = IORD(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 0);

	x_val = (TP_val >> 16) & 0xFFF;
	y_val = TP_val & 0xFFF;
    
    x_val = (((x_val - 160) * 55) >> 8) - 24;
    y_val = (((y_val - 300) * 34) >> 8) - 24;
    
    if (y_val > 415) y_val = 415;
    if (y_val < 0) y_val = 0;
    if (x_val < 0) x_val = 0;    
    if (x_val < 640) {
        TouchXYFlag = 1;
        if (x_val > 575) x_val = 575;
        TouchXVal = x_val;
        TouchYVal = y_val;
        printf("Touched at: x: %d, y: %d\n", TouchXVal, TouchYVal);

		sprintf(Text, "Touched: %03d %03d", TouchXVal, TouchYVal);
		alt_up_character_lcd_set_cursor_pos(lcd_0, 0, 1);
		alt_up_character_lcd_string(lcd_0, Text);

		IOWR(NIOS_LCD_CAMERA_COMPONENT_0_LCDBOX_BASE, 0, (box_flag << 31) | ((cur_s_yval + 8) << 10) | (cur_s_xval + 8));
    } 

    x_val = (TP_val >> 20) & 0xFF; y_val = (TP_val >> 4) & 0xFF;
        	
    if (((TP_val >> 31) & 0x1) && (x_val >= 0xC9) && (x_val <= 0xF1)) {
        if ((y_val >= 0x17) && (y_val <= 0x33)) { // Key 0
            key = 0;
            IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x1);
        }
        if ((y_val >= 0x3D) && (y_val <= 0x58)) { // Key 1
            key = 1;
            IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x2);
        }
        if ((y_val >= 0x62) && (y_val <= 0x7E)) { // Key 2
            key = 2;
            IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x4);
        }
        if ((y_val >= 0x88) && (y_val <= 0xA4)) { // Key 3
            key = 3;
            IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x8);
        }
        if ((y_val >= 0xAE) && (y_val <= 0xC9)) { // Key 4
            key = 4;
            IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x10);
        }
        if ((y_val >= 0xD3) && (y_val <= 0xEF)) { // Key 5
            key = 5;
            IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x20);
        }
    } else IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 0, 0x0);
    
    if (IORD(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 2) & 0x2) { // posedge
        switch (key) {
            case 0 : 
                if (run == 1) {
                    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x8);
                    run = 0;
                } else {
                    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x4);
                    run = 1;
                }
                break;
			case 2 :
				if (box_flag == 0) box_flag = 1;
				else box_flag = 0;
				
				IOWR(NIOS_LCD_CAMERA_COMPONENT_0_LCDBOX_BASE, 0, (box_flag << 31) | ((cur_s_yval + 8) << 10) | (cur_s_xval + 8));
			break;
            case 4 : 
                if (exposure <= 0xFEFF) exposure += 0x0100;
                IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 0, exposure);
                IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x2);
                break;                              
            case 5 : 
                if (exposure >= 0x0100) exposure -= 0x0100;
                IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 0, exposure);
                IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x2);
                break;
        }
    }
    
    TP_val = IORD(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 2);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 2, TP_val & 0x30);

	return_code = OSSemPost(TPChangeSemaphore);
	alt_ucosii_check_return_code(return_code);

	OSIntExit();
}

void init_LCD_camera() {
	exposure = 0x0C00;
	run = 1;
	config = 0;
	TouchXVal = 128;
	TouchYVal = 128;
	cur_s_xval = TouchXVal - 8;
	cur_s_yval = TouchYVal - 8;
	box_flag = 1;
	
	alt_irq_register(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_IRQ, NULL, (void *)TouchPanel_int);
    
	// initialize the touch panel
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 2, 0x0);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_TOUCHPANEL_BASE, 1, 0x400000);

    // initialize the camera
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 0, exposure);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x2);
    while ((IORD(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1) & 0x1) == 0);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CAMERA_BASE, 1, 0x4);
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_IMAGELINE_BASE, 1, 0);

    // initialize the buttons
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_CONSOLE_BASE, 1, 0x0);
}
