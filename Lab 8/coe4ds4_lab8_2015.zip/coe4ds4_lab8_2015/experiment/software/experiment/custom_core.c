// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

extern void *performance_name;

// Semaphore from uCOS
extern OS_EVENT *PBSemaphore[];
OS_EVENT *CCDoneSemaphore;
OS_EVENT *TPChangeSemaphore;

extern alt_up_character_lcd_dev *lcd_0;

// ISR when done is asserted
void handle_done_interrupts(void *context, alt_u32 id)
{
    INT8U return_code = OS_NO_ERR;
	
	OSIntEnter();
	
	return_code = OSSemPost(CCDoneSemaphore);
   	alt_ucosii_check_return_code(return_code);

    // Reset the edge capture register
    set_pio_edge_cap(STATUS_DONE_BASE, 0x00000000);
  
	OSIntExit();
}

// Function for initializing the ISR of the PBs
// The PBs are setup to generate interrupt on falling edge,
// and the interrupt is captured when the edge comes
void init_done_isr() {
  // Enable done interrupts
  set_pio_irq_mask(STATUS_DONE_BASE, 0x0);

  // Reset the edge capture register
  set_pio_edge_cap(STATUS_DONE_BASE, 0x00000000);
  
  // Register the interrupt handler
  alt_irq_register( STATUS_DONE_IRQ, NULL, handle_done_interrupts );
}

void custom_core_task(void* pdata) {
    INT8U return_code = OS_NO_ERR;
	int switches, prev_mode = 8;
	   char Text[16];
       
    while (1) {
        // Wait for PB3
        // Task will be suspended while waiting
//        OSSemPend(PBSemaphore[3], 0, &return_code);
        // OSSemPend(TPChangeSemaphore, 0, &return_code);
//        alt_ucosii_check_return_code(return_code);
		
		switches = inport(SWITCH_I_BASE);
		
		srand(switches);

	    switch (switches & 0x00000007) {
            case 2:
                debug_read_search_ram((switches & 0x0000FF80) >> 4);
                break;            	
            case 3:            
                debug_read_reference_ram((switches & 0x0000FF80) >> 4);
				break;
			case 4:
				debug_read_sinc_rom((switches & 0x0000FF80) >> 4);
				break;
			case 5:
                debug_fft_offset();
                sprintf(Text, "FFT DC offset  ");
				break;
			case 6:
                if (prev_mode != 6) {
                    custom_SD_queue_write("Correlation mode\n", 17);
                    prev_mode = 6;
                }
                debug_correlation_flow();
                sprintf(Text, "Correlation    ");
                break;
            case 7:                
                if (prev_mode != 7) {
                    custom_SD_queue_write("FFT mode\n", 9);
                    prev_mode = 7;
                }
				debug_full_flow();
                sprintf(Text, "Full FFT       ");
                break;
            default: printf("Unsupported switch configuration\n");
        }	

	    alt_up_character_lcd_set_cursor_pos(lcd_0, 0, 0);

	    alt_up_character_lcd_string(lcd_0, Text);
	
		if (((switches & 0x00000007) != 7) && ((switches & 0x00000007) != 6) && ((switches & 0x00000007) != 5)) {
			OSSemPend(PBSemaphore[3], 0, &return_code);
			alt_ucosii_check_return_code(return_code);
		}                        
    }
}
