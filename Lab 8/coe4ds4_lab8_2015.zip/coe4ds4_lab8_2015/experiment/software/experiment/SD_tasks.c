// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

// link to external definition of PBSemaphone
extern OS_EVENT *PBSemaphore[4];

// Definition of flag
OS_FLAG_GRP *SDCardFlag;

// Definition of mutex
OS_EVENT *SDMutex;

// Definition of message queue
OS_EVENT *SDWriteQueue;

// Definition of task stacks
OS_STK	  SD_presence_detect_stk[TASK_STACKSIZE];
OS_TCB	  SD_presence_detect_tcb;
OS_STK	  SD_write_stk[TASK_STACKSIZE];
OS_TCB	  SD_write_tcb;

void SD_presence_detect_task(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	OS_FLAGS SD_flag_value;
	char filename[13];
	int status;

	while (1) {
		SD_flag_value = OSFlagQuery(SDCardFlag, &return_code);
		if ((SD_flag_value & SD_PRESENCE_FLAG) == 0) {
			if (sd_card_is_Present()) {
				printf("SD card is inserted\n");
				OSFlagPost(SDCardFlag, SD_PRESENCE_FLAG, OS_FLAG_SET, &return_code);
				alt_ucosii_check_return_code(return_code);
			
				if (sd_card_is_FAT16()) {
					printf("Valid filesystem is detected on SD card\n");
					OSFlagPost(SDCardFlag, SD_FILESYSTEM_FLAG, OS_FLAG_SET, &return_code);
					alt_ucosii_check_return_code(return_code);	
					
					status = sd_card_find_first(".", filename);
					switch (status) {
	                    case 0: printf("Success\n"); break;
	                    case 1: printf("Invalid directory\n"); break;
	                    case 2: printf("No card or incorrect FS\n"); break;
	                }
				}
			}
		} else {
			if (!sd_card_is_Present()) {
				printf("SD card is removed\n");
				
				// clear all the flags
				OSFlagPost(SDCardFlag, 0xFF, OS_FLAG_CLR, &return_code);
				alt_ucosii_check_return_code(return_code);
			}
		}

		// Check if SD card is present every 500ms
		OSTimeDlyHMSM(0, 0, 0, 500);
	}
}

void SD_write_task(void *pdata) {
	INT8U return_code = OS_NO_ERR;
	short int file_handle;
	unsigned short int data;
	OS_FLAGS flag_values;
	int file_opened = 0;
	static int file_number = 0;
	char filename[13];
	int status;
	int image_size;
	
	while (1) {
		OSFlagPend(SDCardFlag, SD_PRESENCE_FLAG | SD_FILESYSTEM_FLAG | SD_WRITE_DATA_READY, OS_FLAG_WAIT_SET_ALL, 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		// printf("W: getting SDMutex\n");
		OSMutexPend(SDMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		
		if (file_opened == 1) {
			do {
				data = (unsigned short int)OSQAccept(SDWriteQueue, &return_code);
				if (return_code == OS_NO_ERR) {
					status = sd_card_write(file_handle, (char)(data & 0xFF));
					image_size++;
				}
			} while (return_code == OS_NO_ERR);			

			flag_values = OSFlagQuery(SDCardFlag, &return_code);
			alt_ucosii_check_return_code(return_code);
			if (flag_values & SD_WRITE_NEW_FILE) {		
				file_opened = 0;
				sd_card_fclose(file_handle);

				printf("Logfile %s complete (%d bytes)\n", filename, image_size);

				OSFlagPost(SDCardFlag, SD_WRITE_NEW_FILE, OS_FLAG_CLR, &return_code);
				alt_ucosii_check_return_code(return_code);
			}

		}
//		printf("WQ emptied (%d bytes)\n", image_size);			

		if (file_opened == 0) {
			sprintf(filename, "LOG%03d.txt", file_number++);
            while ((file_handle = sd_card_fopen(filename, 1)) < 0) {
                sprintf(filename, "LOG%03d.txt", file_number++);                 
            }
			file_opened = 1;			
            printf("Opening new logfile (%s)...\n", filename);

			status = sd_card_write(file_handle, 'L');
			status = sd_card_write(file_handle, 'o');
			status = sd_card_write(file_handle, 'g');
			status = sd_card_write(file_handle, 'f');
			status = sd_card_write(file_handle, 'i');
			status = sd_card_write(file_handle, 'l');
			status = sd_card_write(file_handle, 'e');
			status = sd_card_write(file_handle, ' ');
			image_size = file_number - 1;
			status = sd_card_write(file_handle, (char)((image_size/100 + 48) & 0xFF));
			image_size = image_size % 100;
			status = sd_card_write(file_handle, (char)((image_size/10 + 48) & 0xFF));
			image_size = image_size % 10;
			status = sd_card_write(file_handle, (char)((image_size + 48) & 0xFF));			
			status = sd_card_write(file_handle, '\n');
			status = sd_card_write(file_handle, '\n');
			image_size = 0;
		}

		return_code = OSMutexPost(SDMutex);
		alt_ucosii_check_return_code(return_code);
		
		OSFlagPost(SDCardFlag, SD_WRITE_DATA_READY, OS_FLAG_CLR, &return_code);
		alt_ucosii_check_return_code(return_code);
		
		OSFlagPost(SDCardFlag, SD_WRITE_NEED_FILL, OS_FLAG_SET, &return_code);
		alt_ucosii_check_return_code(return_code);
	}
}
