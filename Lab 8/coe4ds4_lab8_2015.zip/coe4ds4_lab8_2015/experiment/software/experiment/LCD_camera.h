// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#ifndef __LCD_camera_H__
#define __LCD_camera_H__

// Global functions
void TouchPanel_int(void);
void init_LCD_camera();

#endif
