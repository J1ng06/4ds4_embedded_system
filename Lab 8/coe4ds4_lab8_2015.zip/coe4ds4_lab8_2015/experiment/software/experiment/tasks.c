// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

// For the performance counter
void *performance_name = PERFORMANCE_COUNTER_BASE;

// Definition of semaphore for PBs
OS_EVENT *PBSemaphore[4];
extern OS_EVENT *CCDoneSemaphore;

// Definition of task stacks
OS_STK	  initialize_task_stk[TASK_STACKSIZE];
OS_STK	  task_launcher_stk[TASK_STACKSIZE];

//OS_STK    custom_task_0_stk[TASK_STACKSIZE];
//OS_TCB    custom_task_0_tcb;

OS_STK    custom_core_task_stk[TASK_STACKSIZE];
OS_TCB    custom_core_task_tcb;

extern OS_STK    SD_presence_detect_stk[TASK_STACKSIZE];
extern OS_TCB    SD_presence_detect_tcb;
extern OS_STK    SD_write_stk[TASK_STACKSIZE];
extern OS_TCB    SD_write_tcb;
//extern OS_STK    SD_read_stk[TASK_STACKSIZE];
//extern OS_TCB    SD_read_tcb;
//extern OS_STK    compute_Y_stk[TASK_STACKSIZE];
//extern OS_TCB    compute_Y_tcb;
//extern OS_STK    process_Y_stk[TASK_STACKSIZE];
//extern OS_TCB    process_Y_tcb;

extern void SD_presence_detect_task(void* pdata);
//extern void SD_read_task(void *pdata);
extern void SD_write_task(void *pdata);
//extern void compute_Y_task(void *pdata);
//extern void process_Y_task(void *pdata);

/*
// Custom task 0
// It has a high priority to monitor PB0
// And it display OS info when PB0 is pressed
void custom_task_0(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	OS_TCB tcb_data;
	OS_MUTEX_DATA mutex_data;
	OS_SEM_DATA sem_data;
	int i;
	INT8U x, y;

	while (1) {
		// Wait for PB0
		OSSemPend(PBSemaphore[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("Printing task info:\n");
		for (i = 0; i < 64; i++) {
			return_code = OSTaskQuery(i, &tcb_data);
			if (return_code == OS_NO_ERR) {
				printf("Task %d: Priority = %d, Status = %d, # of times active = %4ld, delay=%d\n",
					i,
					tcb_data.OSTCBPrio,
					tcb_data.OSTCBStat,
					tcb_data.OSTCBCtxSwCtr,
                    tcb_data.OSTCBDly);
			}
		}

		printf("\n");
		printf("Printing Semaphore info:\n");
		for (i = 0; i < NUM_PB_BUTTON; i++) {
			return_code = OSSemQuery(PBSemaphore[i], &sem_data);
			if (return_code == OS_NO_ERR) {
				printf("PB%d: count = %d\n",
					i,
					sem_data.OSCnt);
			}
		}
        return_code = OSSemQuery(CCDoneSemaphore, &sem_data);
        if (return_code == OS_NO_ERR) {
            printf("CC: count = %d\n",
                sem_data.OSCnt);
        }
        
		printf("Overall stats:\n");
		printf("# of task created  : %d\n", OSTaskCtr);
		printf("# of context switch: %4ld\n", OSCtxSwCtr);
		OSTimeDlyHMSM(0, 0, 0, 100);
	}
}
*/

// Task launcher
// It creates all the custom tasks
// And then it deletes itself
void task_launcher(void *pdata) {
    INT8U return_code = OS_NO_ERR;

    #if OS_CRITICAL_METHOD == 3
            OS_CPU_SR cpu_sr;
    #endif

    printf("Starting task launcher...\n");
    while (1) {
        OS_ENTER_CRITICAL();
        printf("Creating tasks...\n");
/* Object tracker tasks */
/*
        return_code = OSTaskCreateExt(custom_task_0,
            NULL,
            (void *)&custom_task_0_stk[TASK_STACKSIZE-1],
            CUSTOM_TASK_0_PRIORITY,
            CUSTOM_TASK_0_PRIORITY,
            custom_task_0_stk,
            TASK_STACKSIZE,
            &custom_task_0_tcb,
            0);
        alt_ucosii_check_return_code(return_code);
*/
        return_code = OSTaskCreateExt(custom_core_task,
            NULL,
            (void *)&custom_core_task_stk[TASK_STACKSIZE-1],
            CUSTOM_CORE_TASK_PRIORITY,
            CUSTOM_CORE_TASK_PRIORITY,
            custom_core_task_stk,
            TASK_STACKSIZE,
            &custom_core_task_tcb,
            0);
        alt_ucosii_check_return_code(return_code);
/* SD card tasks */
        return_code = OSTaskCreateExt(SD_presence_detect_task,
            NULL,
            (void *)&SD_presence_detect_stk[TASK_STACKSIZE-1],
            SD_PRESENCE_DETECT_PRIORITY,
            SD_PRESENCE_DETECT_PRIORITY,
            &SD_presence_detect_stk[0],
            TASK_STACKSIZE,
            &SD_presence_detect_tcb,
            0);
        alt_ucosii_check_return_code(return_code);
/*
        return_code = OSTaskCreateExt(SD_read_task,
            NULL,
            (void *)&SD_read_stk[TASK_STACKSIZE-1],
            SD_READ_PRIORITY,
            SD_READ_PRIORITY,
            &SD_read_stk[0],
            TASK_STACKSIZE,
            &SD_read_tcb,
            0);
        alt_ucosii_check_return_code(return_code);
*/
        return_code = OSTaskCreateExt(SD_write_task,
            NULL,
            (void *)&SD_write_stk[TASK_STACKSIZE-1],
            SD_WRITE_PRIORITY,
            SD_WRITE_PRIORITY,
            &SD_write_stk[0],
            TASK_STACKSIZE,
            &SD_write_tcb,
            0);
        alt_ucosii_check_return_code(return_code);
/*
        return_code = OSTaskCreateExt(compute_Y_task,
            NULL,
            (void *)&compute_Y_stk[TASK_STACKSIZE-1],
            COMPUTE_Y_PRIORITY,
            COMPUTE_Y_PRIORITY,
            &compute_Y_stk[0],
            TASK_STACKSIZE,
            &compute_Y_tcb,
            0);
        alt_ucosii_check_return_code(return_code);

        return_code = OSTaskCreateExt(process_Y_task,
            NULL,
            (void *)&process_Y_stk[TASK_STACKSIZE-1],
            PROCESS_Y_PRIORITY,
            PROCESS_Y_PRIORITY,
            &process_Y_stk[0],
            TASK_STACKSIZE,
            &process_Y_tcb,
            0);
        alt_ucosii_check_return_code(return_code);
*/
        printf("Finish creating tasks...\n");

        printf("\n");
        OSTimeDlyHMSM(0, 0, 1, 0);

        return_code = OSTaskDel(OS_PRIO_SELF);
        alt_ucosii_check_return_code(return_code);

        OS_EXIT_CRITICAL();
    }
}

