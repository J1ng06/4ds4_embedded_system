// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Digital Systems Design course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

extern void *performance_name;

// Semaphore from uCOS
extern OS_EVENT *PBSemaphore[];
extern OS_EVENT *CCDoneSemaphore;
extern OS_EVENT *TPChangeSemaphore;

// Definitions for message queue
extern OS_FLAG_GRP *SDCardFlag;
extern OS_EVENT *SDWriteQueue;

//extern unsigned int done_mask;

unsigned int search_image[RAM_SIZE]/* __attribute__ ((section(".rwdata")))*/;
unsigned int reference_image[RAM_SIZE]/* __attribute__ ((section(".rwdata")))*/;
unsigned int result_real[RAM_SIZE]/* __attribute__ ((section(".rwdata")))*/;
unsigned int result_imag[RAM_SIZE]/* __attribute__ ((section(".rwdata")))*/;

extern int tracked_x, tracked_y;
extern int cur_s_xval;
extern int cur_s_yval;
extern int box_flag;
extern int TouchXVal, TouchYVal, TouchXYFlag;

int stable_count = 0;

void custom_SD_queue_write(char *logtext, int logtext_lim) {
	INT8U return_code = OS_NO_ERR;
	int logtext_pos = 0;

	while (logtext_pos < logtext_lim) {
			if (OSQPost(SDWriteQueue, (void *)(logtext[logtext_pos] & 0xFF)) == OS_Q_FULL) {
//			printf("WriteQueue full\n");
			OSFlagPost(SDCardFlag, SD_WRITE_NEED_FILL, OS_FLAG_CLR, &return_code);
			alt_ucosii_check_return_code(return_code);
			OSFlagPost(SDCardFlag, SD_WRITE_DATA_READY, OS_FLAG_SET, &return_code);
			alt_ucosii_check_return_code(return_code);
			OSFlagPend(SDCardFlag, SD_PRESENCE_FLAG | SD_FILESYSTEM_FLAG | SD_WRITE_NEED_FILL, OS_FLAG_WAIT_SET_ALL, 0, &return_code);
			alt_ucosii_check_return_code(return_code);
		} else logtext_pos++;				
	} 	
}

void custom_SD_new_logfile() {
	INT8U return_code = OS_NO_ERR;
    int TP_sem_value;

	OSFlagPost(SDCardFlag, SD_WRITE_NEED_FILL, OS_FLAG_CLR, &return_code);
	alt_ucosii_check_return_code(return_code);
	OSFlagPost(SDCardFlag, SD_WRITE_NEW_FILE, OS_FLAG_SET, &return_code);
	alt_ucosii_check_return_code(return_code);
	OSFlagPost(SDCardFlag, SD_WRITE_DATA_READY, OS_FLAG_SET, &return_code);
	alt_ucosii_check_return_code(return_code);
	OSFlagPend(SDCardFlag, SD_PRESENCE_FLAG | SD_FILESYSTEM_FLAG | SD_WRITE_NEED_FILL, OS_FLAG_WAIT_SET_ALL, 0, &return_code);
	alt_ucosii_check_return_code(return_code);
    
    do { TP_sem_value = OSSemAccept(TPChangeSemaphore);
    } while (TP_sem_value > 0);
}

void debug_read_work1_ram(int mode, int port, int print_size) {
    int i;
    unsigned int debug_data0, debug_data1;
	unsigned int result_data0, result_data2, result_data3;
	
	printf("Read from Work1 ram port %d\n", port);
	if (port == 0)
		outport(DEBUG_INPUT_SELECT_BASE, 0x2);
	else 
		outport(DEBUG_INPUT_SELECT_BASE, 0x3);
	
	printf("Set work1 RAM to mode %d for reading\n", mode);
    debug_data1 = 0x00000000 | mode << 24;
   	outport(DEBUG_OUTPUT_1_BASE, debug_data1);

	printf("Setting RAM MUX\n");
	outport(CONTROL_RAM_MUX_BASE, 0x0030);
    
	for (i = 0; i < RAM_SIZE; i++) {
		seg7_show(SEG7_DISPLAY_0_BASE, i);
		debug_data0 = ((i & 0x00000FFF) << 20);
		outport(DEBUG_OUTPUT_0_BASE, debug_data0);
		
		result_data0 = inport(DEBUG_INPUT_0_BASE);
		result_data2 = inport(DEBUG_INPUT_2_BASE);
		result_data3 = inport(DEBUG_INPUT_3_BASE);
		
		if (i < print_size) {			
			printf("%02X, %02X, %X: R: %05X, I: %05X\n", 
	            (result_data0 & 0x00001F80) >> 7,
	            (result_data0 & 0x0000007E) >> 1,
	            (result_data0 & 0x00000001),
				result_data2 & 0x000FFFFF,
				result_data3 & 0x000FFFFF
				);
			OSTimeDly(500);
		}
	}
}

void debug_read_work2_ram(int mode, int port, int print_size) {
    int i;
    unsigned int debug_data0, debug_data1;
	unsigned int result_data0, result_data2, result_data3;
	
	printf("Read from Work2 ram port %d\n", port);
	if (port == 0)
		outport(DEBUG_INPUT_SELECT_BASE, 0x4);
	else
		outport(DEBUG_INPUT_SELECT_BASE, 0x5);

	printf("Set work2 RAM to mode %d for reading\n", mode);
    debug_data1 = 0x00000000 | mode << 24;
   	outport(DEBUG_OUTPUT_1_BASE, debug_data1);

	printf("Setting RAM MUX\n");
	outport(CONTROL_RAM_MUX_BASE, 0x0300);
    
	for (i = 0; i < RAM_SIZE; i++) {
		seg7_show(SEG7_DISPLAY_0_BASE, i);
		debug_data0 = ((i & 0x00000FFF) << 20);
		outport(DEBUG_OUTPUT_0_BASE, debug_data0);
		
		result_data0 = inport(DEBUG_INPUT_0_BASE);
		result_data2 = inport(DEBUG_INPUT_2_BASE);
		result_data3 = inport(DEBUG_INPUT_3_BASE);
					
		if (i < print_size) {			
			printf("%02X, %02X, %X: R: %05X, I: %05X\n", 
	            (result_data0 & 0x00001F80) >> 7,
	            (result_data0 & 0x0000007E) >> 1,
	            (result_data0 & 0x00000001),
				result_data2 & 0x000FFFFF,
				result_data3 & 0x000FFFFF
				);
			OSTimeDly(500);
		}
	}
}

void debug_write_work2_ram(int mode, int port, int addr, int rdata, int idata) {
    unsigned int debug_data0, debug_data1;
    
//    printf("Write to Work2 ram port %d\n", port);
    if (port == 0)
        outport(DEBUG_INPUT_SELECT_BASE, 0x4);
    else
        outport(DEBUG_INPUT_SELECT_BASE, 0x5);

    debug_data0 = ((addr & 0x00000FFF) << 20) | (rdata & 0x000FFFFF);
    outport(DEBUG_OUTPUT_0_BASE, debug_data0);

//    printf("Set work2 RAM to mode %d for writing\n", mode);
    debug_data1 = (mode << 24) | (idata & 0x000FFFFF);
    outport(DEBUG_OUTPUT_1_BASE, debug_data1);
    
    outport(DEBUG_OUTPUT_1_BASE, 0x0);
}

void debug_read_search_ram(int print_size) {
    int i;
    unsigned int debug_data0, debug_data1;
	unsigned int result_data0, result_data3;
	
	printf("Read from search ram\n");
	outport(DEBUG_INPUT_SELECT_BASE, 0x0);
	
    debug_data1 = 0x00000000;
   	outport(DEBUG_OUTPUT_1_BASE, debug_data1);

	printf("Setting RAM MUX\n");
	outport(CONTROL_RAM_MUX_BASE, 0x0004);
    
	for (i = 0; i < RAM_SIZE; i++) {
		seg7_show(SEG7_DISPLAY_0_BASE, i);
		debug_data0 = ((i & 0x00000FFF) << 20);
		outport(DEBUG_OUTPUT_0_BASE, debug_data0);
		
		result_data0 = inport(DEBUG_INPUT_0_BASE);
		result_data3 = inport(DEBUG_INPUT_3_BASE);
					
		if (i < print_size) {			
			printf("%02X, %02X, %X: R: %05X\n", 
	            (result_data0 & 0x00001F80) >> 7,
	            (result_data0 & 0x0000007E) >> 1,
	            (result_data0 & 0x00000001),
				result_data3 & 0x000FFFFF
			);
		
			OSTimeDly(500);
		}
	}
}

void debug_read_reference_ram(int print_size) {
    int i;
    unsigned int debug_data0, debug_data1;
	unsigned int result_data0, result_data3;
	
	printf("Read from referece ram\n");
	outport(DEBUG_INPUT_SELECT_BASE, 0x1);
	
    debug_data1 = 0x00000000;
   	outport(DEBUG_OUTPUT_1_BASE, debug_data1);

	printf("Setting RAM MUX\n");
	outport(CONTROL_RAM_MUX_BASE, 0x0002);
    
	for (i = 0; i < RAM_SIZE; i++) {
		seg7_show(SEG7_DISPLAY_0_BASE, i);
		debug_data0 = ((i & 0x00000FFF) << 20);
		outport(DEBUG_OUTPUT_0_BASE, debug_data0);
		
		result_data0 = inport(DEBUG_INPUT_0_BASE);
		result_data3 = inport(DEBUG_INPUT_3_BASE);
					
		if (i < print_size) {			
			printf("%02X, %02X, %X: R: %05X\n", 
	            (result_data0 & 0x00001F80) >> 7,
	            (result_data0 & 0x0000007E) >> 1,
	            (result_data0 & 0x00000001),
				result_data3 & 0x000FFFFF
			);
		
			OSTimeDly(500);
		}
	}
}

void debug_read_sinc_rom(int print_size) {
    int i;
    unsigned int debug_data0, debug_data1;
	unsigned int result_data0, result_data2, result_data3;
	
	printf("Read from sinc ram\n");
	outport(DEBUG_INPUT_SELECT_BASE, 0x6);
	
    debug_data1 = 0x00000000;
   	outport(DEBUG_OUTPUT_1_BASE, debug_data1);

	printf("Setting RAM MUX\n");
	outport(CONTROL_RAM_MUX_BASE, 0x0001);
    
	for (i = 0; i < RAM_SIZE; i++) {
		seg7_show(SEG7_DISPLAY_0_BASE, i);
		debug_data0 = ((i & 0x00000FFF) << 20);
		outport(DEBUG_OUTPUT_0_BASE, debug_data0);
		
		result_data0 = inport(DEBUG_INPUT_0_BASE);
		result_data2 = inport(DEBUG_INPUT_2_BASE);
		result_data3 = inport(DEBUG_INPUT_3_BASE);
					
		if (i < print_size) {			
			printf("%02X, %02X: R: %05X, I: %05X\n", 
				(result_data0 & 0x00000FC0) >> 6, 
				(result_data0 & 0x0000003F),
				result_data2 & 0x000FFFFF,
				result_data3 & 0x000FFFFF			
			);
		
			OSTimeDly(500);
		}
	}
}

void config_lcd_box(int target_box, int box_flag, int box_data, int yval, int xval) {
    
    // box_data
    // X1XX: invert color
    // 10XX: original image
    // 0000: reference ram
    // 0001: search ram
    // 0010: work2
    
    IOWR(NIOS_LCD_CAMERA_COMPONENT_0_LCDBOX_BASE, target_box, 
            (box_flag << 31) | (box_data << 27)| ((yval) << 10) | (xval));
}

void debug_capture(int r_start, int s_start, int r_row, int r_col, int s_row, int s_col) {
	INT8U return_code = OS_NO_ERR;

    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    if (s_start == 0) 
        set_pio_irq_mask(STATUS_DONE_BASE, (r_start << 5));
    else
        set_pio_irq_mask(STATUS_DONE_BASE, (s_start << 5));    
    
	outport(CONTROL_RAM_MUX_BASE, 0x3000);

	if (r_start != 0) {
		outport(CONTROL_REF1_LOCATION_BASE, (r_row << 10) | (r_col));
	}
	if (s_start != 0) {
		outport(CONTROL_SRCH_LOCATION_BASE, (s_row << 10) | (s_col));
	}
	outport(CONTROL_CAPTURE_BASE, (r_start << 1) | s_start);
	outport(CONTROL_CAPTURE_BASE, 0x0);
	
	OSSemPend(CCDoneSemaphore, 0, &return_code);
    alt_ucosii_check_return_code(return_code);

    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);
}

void debug_dma(int mode, int pc_count) {
	INT8U return_code = OS_NO_ERR;	
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x01);
	
	outport(CONTROL_RAM_MUX_BASE, 0x0000);
    
	if (mode == 0) {
		outport(CONTROL_DMA_BASE, 0x1);
		outport(CONTROL_DMA_BASE, 0x0);
	} else {
		outport(CONTROL_DMA_BASE, 0x3);
		outport(CONTROL_DMA_BASE, 0x2);		
	}

	OSSemPend(CCDoneSemaphore, 0, &return_code);
    alt_ucosii_check_return_code(return_code);

    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);
}

void debug_fft(int mode, int target_ram) {
	INT8U return_code = OS_NO_ERR;

	if (target_ram == 1) 
		outport(CONTROL_RAM_MUX_BASE, 0x00A0);
	else
		outport(CONTROL_RAM_MUX_BASE, 0x0A00);
	
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x10);

	if (mode == 0) {
		if (target_ram == 1) {
			outport(CONTROL_FFT_BASE, 0x0);
			outport(CONTROL_FFT_BASE, 0x1);
			outport(CONTROL_FFT_BASE, 0x0);
		} else {
			outport(CONTROL_FFT_BASE, 0x8);
			outport(CONTROL_FFT_BASE, 0x9);
			outport(CONTROL_FFT_BASE, 0x8);
		}
	} else {
		// IFFT
		if (target_ram == 1) {
			outport(CONTROL_FFT_BASE, 0x2);
			outport(CONTROL_FFT_BASE, 0x3);
			outport(CONTROL_FFT_BASE, 0x2);
		} else {
			outport(CONTROL_FFT_BASE, 0xA);
			outport(CONTROL_FFT_BASE, 0xB);
			outport(CONTROL_FFT_BASE, 0xA);
		}
	}

	OSSemPend(CCDoneSemaphore, 0, &return_code);
	alt_ucosii_check_return_code(return_code);
	
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);
}

void debug_matmul() {
	INT8U return_code = OS_NO_ERR;

    outport(CONTROL_RAM_MUX_BASE, 0x0100);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x02);   

    outport(CONTROL_MATMUL_BASE, 0x1);
    outport(CONTROL_MATMUL_BASE, 0x0);

    OSSemPend(CCDoneSemaphore, 0, &return_code);
    alt_ucosii_check_return_code(return_code);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);    
}

void debug_square() {
	INT8U return_code = OS_NO_ERR;

    outport(CONTROL_RAM_MUX_BASE, 0x0018);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x04);
    
    outport(CONTROL_SQUARE_BASE, 0x1);
    outport(CONTROL_SQUARE_BASE, 0x0);

    OSSemPend(CCDoneSemaphore, 0, &return_code);
    alt_ucosii_check_return_code(return_code);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);
}

void debug_mulsub() {
	INT8U return_code = OS_NO_ERR;

    outport(CONTROL_RAM_MUX_BASE, 0x0040);

    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x08);
    
    outport(CONTROL_MULSUB_BASE, 0x1);
    outport(CONTROL_MULSUB_BASE, 0x0);

    OSSemPend(CCDoneSemaphore, 0, &return_code);
    alt_ucosii_check_return_code(return_code);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);
}

void debug_cal_object_position(int print_size) {
	int i;
    unsigned int debug_data0, debug_data1;
	unsigned int result_data0, result_data2, result_data3;
	int min_r, min_i;
	int signed_real;
	int row, col;
	
	outport(DEBUG_INPUT_SELECT_BASE, 0x2);
	
    debug_data1 = 0x00000000;
   	outport(DEBUG_OUTPUT_1_BASE, debug_data1);

	outport(CONTROL_RAM_MUX_BASE, 0x0030);
    
	min_r = (0x1 << 19) - 1;
	min_i = 256;
	for (i = 0; i < 256; i++) {
		// seg7_show(SEG7_DISPLAY_0_BASE, i);
		row = i >> 4;
		col = i & 0xF;
		debug_data0 = (row << 26) | (col << 20);
		outport(DEBUG_OUTPUT_0_BASE, debug_data0);
		
		result_data0 = inport(DEBUG_INPUT_0_BASE);
		result_data2 = inport(DEBUG_INPUT_2_BASE);
		result_data3 = inport(DEBUG_INPUT_3_BASE);
		
		if (((result_data2 >> 19) & 0x1) == 1) {
			signed_real = (result_data2 & 0x000FFFFF) - (0x1 << 20);
		} else {
			signed_real = result_data2;
		}

		// printf("r=%d c=%d sr=%d\n", i >> 4, i & 0xF, signed_real);
		// OSTimeDly(500);
		
		if (signed_real < min_r) {
			min_r = signed_real;
			min_i = i;
		}
	}
	
	tracked_y = min_i >> 4;
	tracked_x = min_i & 0xF;
		
	// printf("Location: x: %d y: %d value: %d\n", tracked_x, tracked_y, min_r);
}

void debug_full_flow() {
	int print_size = 16;
    int switches;
	int TP_sem_value;
	int r_start;
	int box_data;
	char logtext[25];
	int logtext_lim;
	
//	printf("The full flow for object tracking\n");
	
    switches = inport(SWITCH_I_BASE);
    
	box_data = (switches & 0x000000F0) >> 4;
    switches = (switches & 0x00000008) >> 3;

    // Start the performance counter
    // PERF_START_MEASURING(performance_name);

	if (switches == 0) {
		TP_sem_value = OSSemAccept(TPChangeSemaphore);
		
		r_start = 0;
		if ((TP_sem_value > 0) && (TouchXYFlag)) {
            // Touched within image
            stable_count = 0;
            r_start = 1;
            sprintf(logtext, "Closing\n"); logtext_lim = 8;
            custom_SD_queue_write(logtext, logtext_lim);
            custom_SD_new_logfile();
            sprintf(logtext, "FFT - Touch");
            logtext_lim = 11;
            TouchXYFlag = 0;
		} else {
			if (tracked_x == 8 && tracked_y == 8) 
				stable_count++;
			else stable_count = 0;
			
			if (stable_count == 3) {
				// update ref ram
				r_start = 1;
				stable_count = 0;
				sprintf(logtext, "\tUpdate");
				logtext_lim = 7;
			} else {
				sprintf(logtext, "\t\tTrack");
				logtext_lim = 7;
			}
			TouchXVal += tracked_x - 8;
			TouchYVal += tracked_y - 8;
		}
		cur_s_xval = TouchXVal - 8;
		cur_s_yval = TouchYVal - 8;
		if (cur_s_xval < 0) {
			cur_s_xval = 0;
			TouchXVal = 0;
		}
		if (cur_s_yval < 0) {
			cur_s_yval = 0;
			TouchYVal = 0;
		}
		
		seg7_show(SEG7_DISPLAY_0_BASE, 
			(tracked_x << 28) | (tracked_y << 24) | (cur_s_xval << 12) | stable_count);
        config_lcd_box(0, box_flag, box_data, TouchYVal, TouchXVal);
		
		debug_capture(r_start, 1, TouchYVal, TouchXVal, cur_s_yval, cur_s_xval);		

		if (r_start == 1) {
			printf("%s %3d %3d\n", logtext, TouchYVal, TouchXVal);
		} else {
			if (tracked_y < 8)
				printf("%s -%d ", logtext, 8 - tracked_y);
			else printf("%s  %d ", logtext, tracked_y - 8);
			if (tracked_x < 8)
				printf("-%d\n", 8 - tracked_x);
			else printf(" %d\n", tracked_x - 8);
		}
	}

    // PERF_BEGIN(performance_name, 1);
	
//	printf("Step 1: Transfer search image to work1 RAM\n");
	debug_dma(0, 1);

//	printf("Step 2: FFT on work1 RAM\n");
	debug_fft(0, 1);

//	printf("Step 3: Transfer Ref image to work2 RAM\n");
	debug_dma(1, 3);
	
//	printf("Step 4: FFT on work2 RAM\n");
	debug_fft(0, 2);	
	
//	printf("Step 5: Matrix multiply between work1 and work2, then store result back to work2\n");
	debug_matmul();
	
//	printf("Step 6: Fill work1 with square of search image\n");
	debug_square();
	
//	printf("Step 7: FFT on work1 RAM\n");
	debug_fft(0, 1);	
	
//	printf("Step 8: Multiply and subtract with sinc rom for data in work1 and work2 ram, then store to work1 ram\n");
	debug_mulsub();
			
//	printf("Step 9: IFFT on work1\n");
	debug_fft(1, 1);	

//	printf("Step 10: Get minimum\n");
	debug_cal_object_position(print_size);

	//     PERF_END(performance_name, 1);
	//     PERF_STOP_MEASURING(performance_name);
}

void debug_correlation() {
	INT8U return_code = OS_NO_ERR;

    outport(CONTROL_RAM_MUX_BASE, 0x0000);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x80);
    
	outport(CONTROL_CORRELATION_BASE, 0x2);
	outport(CONTROL_CORRELATION_BASE, 0x3); 
	outport(CONTROL_CORRELATION_BASE, 0x2);
	
    OSSemPend(CCDoneSemaphore, 0, &return_code);
    alt_ucosii_check_return_code(return_code);
    
    outport(CONTROL_CORRELATION_BASE, 0x0);
    
    set_pio_edge_cap(STATUS_DONE_BASE, 0x0);
    set_pio_irq_mask(STATUS_DONE_BASE, 0x0);

	tracked_y = inport(CORRELATION_RESULT_BASE);
	tracked_x = tracked_y & 0xF; tracked_y >>= 4;
}

void debug_correlation_flow() {
    int switches;
	int TP_sem_value;
	int r_start;
	int box_data;
	char logtext[25];
	int logtext_lim;
	
//	printf("Object tracking by correlation\n");
	
    switches = inport(SWITCH_I_BASE);
    
	box_data = (switches & 0x000000F0) >> 4;
    switches = (switches & 0x00000008) >> 3;

    // Start the performance counter
    PERF_START_MEASURING(performance_name);

	if (switches == 0) {
		TP_sem_value = OSSemAccept(TPChangeSemaphore);
		
		r_start = 0;
		if ((TP_sem_value > 0) && (TouchXYFlag)) {
            // Touched within image
			stable_count = 0;
            r_start = 1;
            sprintf(logtext, "Closing\n"); logtext_lim = 8;
            custom_SD_queue_write(logtext, logtext_lim);
            custom_SD_new_logfile();
            sprintf(logtext, "Corr - Touch");
            logtext_lim = 12;
            TouchXYFlag = 0;
		} else {
			if (tracked_x == 8 && tracked_y == 8) stable_count++;
			else stable_count = 0;
			
			if (stable_count == 3) {
				// update ref ram
				r_start = 1;
				stable_count = 0;
				sprintf(logtext, "\tUpdate");
				logtext_lim = 7;
			} else {
				sprintf(logtext, "\t\tTrack");
				logtext_lim = 7;
			}
			TouchXVal += tracked_x - 8;
			TouchYVal += tracked_y - 8;
		}
		cur_s_xval = TouchXVal - 8;
		cur_s_yval = TouchYVal - 8;
		if (cur_s_xval < 0) {
			cur_s_xval = 0;
			TouchXVal = 0;
		}
		if (cur_s_yval < 0) {
			cur_s_yval = 0;
			TouchYVal = 0;
		}
		
		seg7_show(SEG7_DISPLAY_0_BASE, (tracked_x << 28) | (tracked_y << 24) | (cur_s_xval << 12) | stable_count);
        config_lcd_box(0, box_flag, box_data, TouchYVal, TouchXVal);
		
		debug_capture(r_start, 1, TouchYVal, TouchXVal, cur_s_yval, cur_s_xval);

        if (r_start == 1) {
            printf("%s %3d %3d\n", logtext, TouchYVal, TouchXVal);
        } else {
            if (tracked_y < 8)
                printf("%s -%d ", logtext, 8 - tracked_y);
            else printf("%s  %d ", logtext, tracked_y - 8);
            if (tracked_x < 8)
                printf("-%d\n", 8 - tracked_x);
            else printf(" %d\n", tracked_x - 8);
        }
	}

    PERF_BEGIN(performance_name, 1);
	
//	printf("Step 1: Perform correlation\n");
	debug_correlation();
	
	PERF_END(performance_name, 1);
	PERF_STOP_MEASURING(performance_name);
}

void debug_fft_offset() {
    int switches;
    int TP_sem_value;
    int r_start;
    int box_data;

    int i;
    int addr[25] = {3968, 3969, 3970, 4030, 4031,
                    4032, 4033, 4034, 4094, 4095,
                      62,   63,    0,    1,    2, 
                     126,  127,  128,  190,  191,
                      64,   65,   66,  129,  130
                    };
    
    switches = inport(SWITCH_I_BASE);
    
    box_data = (switches & 0x000000F0) >> 4;

    // Start the performance counter
    // PERF_START_MEASURING(performance_name);
        
    seg7_show(SEG7_DISPLAY_0_BASE, 
        (tracked_x << 28) | (tracked_y << 24) | (cur_s_xval << 12) | stable_count);
    // printf("rx: %d, ry: %d, sx: %d sy: %d tx: %d ty: %d\n", TouchXVal, TouchYVal, cur_s_xval, cur_s_yval, tracked_x, tracked_y);
    
    debug_capture(1, 0, TouchYVal, TouchXVal, cur_s_yval, cur_s_xval);
    debug_dma(1, 3);
    debug_fft(0, 2);
    for (i = 0; i < 25; i++) {
        debug_write_work2_ram(2, 0, addr[i], 0, 0);
    }
    debug_fft(1, 2);

    config_lcd_box(0, 1, box_data, TouchYVal, TouchXVal);
}
