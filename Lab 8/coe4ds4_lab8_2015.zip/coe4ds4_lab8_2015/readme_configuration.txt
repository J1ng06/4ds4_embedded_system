Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
Developed for the Digital Systems Design course (COE4DS4)
Department of Electrical and Computer Engineering
McMaster University, Ontario, Canada

This file contains instructions for configuration in coe4ds4 lab8.

Switch Configuration
====================

	switches[7:4] - LCD box config
		= 0xxx - show image
		= 1000 - show reference RAM
		= 1001 - show search RAM
	switches[2:0] - flow config
		= 010 - read search RAM (for debugging)
		= 011 - read reference RAM (for debugging)
		= 101 - FFT offset calculation (not used)
		= 110 - correlation based
		= 111 - FFT based

Consult custom_core.c and custom_functions.c for switch configuration implementation

SOPC Components
===============

The SOPC contains components for controlling each hardware component.
In each one, bit[0] is used as the start signal.

The done signals are organized into a register generating an interrupt with bits as follows:

	bit [7] - correlation_done
	bit [6] - unused
	bit [5] - capture_done
	bit [4] - FFT_done
	bit [3] - mulsub_done
	bit [2] - square_done
	bit [1] - matmul_done
	bit [0] - dma_done

The correlation unit provides a coordinate result directly:

	bits [7:4] - row (y) of min position
	bits [3:0] - col (x) of min position

Box drawing on the LCD is controlled by a 32-bit register:

	bit  [31] - draw box enable
	bit  [30] - source (0 = image, 1 = ram)
	bit  [29] - invert flag
	bits [28:27] - ram select 
		= 01 : Search_RAM
		= 00 : Reference_RAM
	bits [18:10] - row (y) of box position
	bits [9:0]   - col (x) of box position

Source and destination points for hardware are controlled via configuration registers which drive the mux select lines - check the defines file for codes

	bit  [13]    - search ram port b auxiliary
	bit  [12]    - reference ram port b

	bits [11:10] - work2 ram port b
	bits [9:8]   - work2 ram port a
	bits [7:6]   - work1 ram port b
	bits [5:4]   - work1 ram port a

	bit  [3]     - search ram port b
	bit  [2]     - search ram port a
	bit  [1]     - reference ram port a
	bit  [0]     - sinc rom
