// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"
extern int PB_array[10];
//extern int task_created[4];

// Semaphore from uCOS
//extern OS_EVENT *PBSemaphore[];
void PB_sort(int new){
	int i;
	for (i = 0; i<10;i++){
		if (PB_array[i] == -1){
			PB_array[i] = new;
			break;
		}
	}
}

// Function for post semaphore when PB0 is pressed
void KEY0_Pressed() {
	//static int key0_first_time = 0;
	//int i;
	PB_sort(0);
//	for (i = 0; i<10;i++){
//		printf("%d ",PB_array[i]);
//		}
//	printf("\n");

}

// Function for post semaphore when PB1 is pressed
void KEY1_Pressed() {
	//static int key1_first_time = 0;
	PB_sort(1);

}

// Function for post semaphore when PB2 is pressed
void KEY2_Pressed() {
	//static int key2_first_time = 0;
	PB_sort(2);
}

// Function for post semaphore when PB3 is pressed
void KEY3_Pressed() {
	//static int key3_first_time = 0;
	PB_sort(3);
	//printf("last %d\n", PB_queue_ptr.q[10]);
}
// ISR when any PB is pressed
void handle_button_interrupts()
{
	OSIntEnter();

    outport(LED_GREEN_O_BASE,get_pio_edge_cap(PUSH_BUTTON_I_BASE)*get_pio_edge_cap(PUSH_BUTTON_I_BASE));
    switch(get_pio_edge_cap(PUSH_BUTTON_I_BASE)) {
    case 1: KEY0_Pressed(); break;
    case 2: KEY1_Pressed(); break;
    case 4: KEY2_Pressed(); break;
    case 8: KEY3_Pressed(); break;
    }
    set_pio_edge_cap(PUSH_BUTTON_I_BASE,0x0);

	OSIntExit();
}

// Function for initializing the ISR of the PBs
// The PBs are setup to generate interrupt on falling edge,
// and the interrupt is captured when the edge comes
void init_button_irq() {
  // Enable all 4 button interrupts
  set_pio_irq_mask(PUSH_BUTTON_I_BASE, BUTTON_INT_MASK);

  // Reset the edge capture register
  set_pio_edge_cap(PUSH_BUTTON_I_BASE, 0x0);

  // Register the interrupt handler
  alt_irq_register( PUSH_BUTTON_I_IRQ, NULL, (void*)handle_button_interrupts );
}
