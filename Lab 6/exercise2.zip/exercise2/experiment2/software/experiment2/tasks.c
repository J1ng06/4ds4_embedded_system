// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

// For the performance counter
void *performance_name = PERFORMANCE_COUNTER_0_BASE;

// Definition of semaphore for PBs

// Definition of task stacks
OS_STK	  initialize_task_stk[TASK_STACKSIZE];
OS_STK	  custom_scheduler_stk[TASK_STACKSIZE];
OS_TCB	  custom_scheduler_tcb;

OS_STK	  periodic_task_stk[NUM_TASK][TASK_STACKSIZE];
OS_TCB	  periodic_task_tcb[NUM_TASK];

int PB_array[10];
int task_created[4];

// Struct for storing information about each custom task
typedef struct task_info_struct {
	int priority;
	int execution_time;
	int os_delay;
} task_info_struct;

// Struct for storing information about tasks during dynamic scheduling using the custom_scheduler
typedef struct scheduler_info_struct {
	int valid;
	int id;
	int period;
} scheduler_info_struct;

// Local function prototypes
void custom_delay(int);

// Periodic task 0
// It periodically uses a custom delay to occupy the CPU
// Then it suspends itself for a specified period of time
void periodic_task0(void* pdata) {
	task_info_struct *task_info_ptr;

	task_info_ptr = (task_info_struct *)pdata;
	while (1) {
		//printf("Start periodic_task0 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("Start periodic_task0 (%d priority)\n", task_info_ptr->priority);
		custom_delay(task_info_ptr->execution_time);
		//printf("End	  periodic_task0 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("End	  periodic_task0 (%d priority)\n",task_info_ptr->priority);
		OSTimeDly(task_info_ptr->os_delay);
	}
}

// Periodic task 1
// It periodically uses a custom delay to occupy the CPU
// Then it suspends itself for a specified period of time
void periodic_task1(void* pdata) {
	task_info_struct *task_info_ptr;

	task_info_ptr = (task_info_struct *)pdata;
	while (1) {
		//printf("Start periodic_task1 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("Start periodic_task1 (%d priority)\n", task_info_ptr->priority);
		custom_delay(task_info_ptr->execution_time);
		//printf("End	  periodic_task1 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("End	  periodic_task1 (%d priority)\n",task_info_ptr->priority);
		OSTimeDly(task_info_ptr->os_delay);
	}
}

// Periodic task 2
// It periodically uses a custom delay to occupy the CPU
// Then it suspends itself for a specified period of time
void periodic_task2(void* pdata) {
	task_info_struct *task_info_ptr;

	task_info_ptr = (task_info_struct *)pdata;
	while (1) {
		//printf("Start periodic_task2 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("Start periodic_task2 (%d priority)\n", task_info_ptr->priority);
		custom_delay(task_info_ptr->execution_time);
		//printf("End	  periodic_task2 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("End	  periodic_task2 (%d priority)\n",task_info_ptr->priority);
		OSTimeDly(task_info_ptr->os_delay);
	}
}

// Periodic task 3
// It periodically uses a custom delay to occupy the CPU
// Then it suspends itself for a specified period of time
void periodic_task3(void* pdata) {
	task_info_struct *task_info_ptr;

	task_info_ptr = (task_info_struct *)pdata;
	while (1) {
		//printf("Start periodic_task3 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("Start periodic_task3 (%d priority)\n", task_info_ptr->priority);
		custom_delay(task_info_ptr->execution_time);
		//printf("End	  periodic_task3 (Exe_Time %4d ms) (Dly %1d ms) (%d priority)\n", task_info_ptr->execution_time, task_info_ptr->os_delay, task_info_ptr->priority);
		printf("End	  periodic_task3 (%d priority)\n",task_info_ptr->priority);
		OSTimeDly(task_info_ptr->os_delay);
	}
}

// The custom_scheduler
// It has the highest priority
// It checks the PBs every 500ms
// It a button has been pressed, it creates/deletes the corresponding task in the OS
// When creating a task, it will assign the new task with the lowest priority among the running tasks
void custom_scheduler(void *pdata) {
	INT8U return_code = OS_NO_ERR;
	int i,j = 0;
	int PB_pressed[NUM_PB_BUTTON];
	int sem_value;
	int new_pressed;
	int new_task[4];
	INT8U lowest_priority = 9;
	int num_active_task;	
	// Array of task_info
	task_info_struct task_info[NUM_TASK];
	scheduler_info_struct scheduler_info[NUM_TASK];

	printf("Starting custom scheduler...\n");
	for (i = 0; i<10;i++){
		PB_array[i] = -1;
	}
	for (i = 0; i < NUM_PB_BUTTON; i++) {
		new_task[i] = 0;
		task_info[i].priority = -1;
		task_info[i].execution_time = (rand() % 750) + 1000;
		task_info[i].os_delay = (rand() % 2000) + 10000 - task_info[i].execution_time;
		printf("%d %d %d\n",i,task_info[i].execution_time,task_info[i].os_delay);
	}
	num_active_task = 0;

	while(1){

		if (PB_array[0] == -1) {
			OSTimeDlyHMSM(0, 0, 3, 0);
			continue;
		}

//		for (i = 0; i<10;i++){
//			printf("%d ",PB_array[i]);
//		}
//		printf("\n");
		OSSchedLock();
		for (i = 0; i < 4; i++){
			new_task[i] = 0;
			if (task_info[i].priority > 0){
				return_code = OSTaskChangePrio(task_info[i].priority, TASK_START_PRIORITY + i + 4);
				alt_ucosii_check_return_code(return_code);
			}
		}
		// checking the PB_array
		for (i = 0; i < 10; i++){
			if(PB_array[i] != -1){
				//printf("key3 %d %d \n",task_info[PB_array[i]].priority,TASK_START_PRIORITY);
				if (task_info[PB_array[i]].priority == -1){
					new_task[PB_array[i]] = 1;
					task_info[PB_array[i]].priority = TASK_START_PRIORITY;
					//printf("%d \n",new_task & (1 << i));
					lowest_priority++;
					for (j = 0; j < 4; j++)
					   if ((j != PB_array[i]) && (task_info[j].priority > 0)) task_info[j].priority++;
				}else {
					for (j = 0; j < NUM_PB_BUTTON; j++)
						if (task_info[j].priority > task_info[PB_array[i]].priority) task_info[j].priority--;
					task_info[PB_array[i]].priority = lowest_priority;
				}
			}
		}

		for (i = 0; i<4;i++){
			printf("%d ",task_info[i].priority);
		}
		printf("\n");


		 for (i = 0; i < 4; i++) {
			 //printf("new task%d\n",new_task[i]);
			 //printf("i %d\n",i);
			if (new_task[i] == 1) {
				printf("Creating task %d with prio %d\n",i,task_info[i].priority);
				switch (i) {
				case 0:
					return_code = OSTaskCreateExt(periodic_task0,
									 &task_info[i],
									 (void *)&periodic_task_stk[num_active_task][TASK_STACKSIZE-1],
									 task_info[i].priority,
									 task_info[i].priority,
									 &periodic_task_stk[num_active_task][0],
									 TASK_STACKSIZE,
									 &periodic_task_tcb[num_active_task],
									 0);
				break;
				case 1:
					return_code = OSTaskCreateExt(periodic_task1,
									 &task_info[i],
									 (void *)&periodic_task_stk[num_active_task][TASK_STACKSIZE-1],
									 task_info[i].priority,
									 task_info[i].priority,
									 &periodic_task_stk[num_active_task][0],
									 TASK_STACKSIZE,
									 &periodic_task_tcb[num_active_task],
									 0);
					alt_ucosii_check_return_code(return_code);
				break;
				case 2:
					return_code = OSTaskCreateExt(periodic_task2,
									 &task_info[i],
									 (void *)&periodic_task_stk[num_active_task][TASK_STACKSIZE-1],
									 task_info[i].priority,
									 task_info[i].priority,
									 &periodic_task_stk[num_active_task][0],
									 TASK_STACKSIZE,
									 &periodic_task_tcb[num_active_task],
									 0);
					alt_ucosii_check_return_code(return_code);
				break;
				default:
					return_code = OSTaskCreateExt(periodic_task3,
									 &task_info[i],
									 (void *)&periodic_task_stk[num_active_task][TASK_STACKSIZE-1],
									 task_info[i].priority,
									 task_info[i].priority,
									 &periodic_task_stk[num_active_task][0],
									 TASK_STACKSIZE,
									 &periodic_task_tcb[num_active_task],
									 0);
					alt_ucosii_check_return_code(return_code);
				break;
				}
				num_active_task++;
				//printf("return code \n",return_code);
				alt_ucosii_check_return_code(return_code);
			} else if (task_info[i].priority > 0) {
				//printf("buf %d, task_prio %d \n",TASK_START_PRIORITY + i + 4,task_info[i].priority);
				return_code = OSTaskChangePrio(TASK_START_PRIORITY + i + 4, task_info[i].priority);
				printf("return code \n",return_code);
				alt_ucosii_check_return_code(return_code);
			}

		 }
		for (i = 0; i < 4; i++) {
			if (task_info[i].priority > 0){
				printf("Task %d: priority: %d, execution time: %dms \n",i, task_info[i].priority, task_info[i].execution_time);
			}else{
				printf("Task %d: Not Created.\n",i);
			}
		}
			//reset the PB_array
			for (i = 0; i<10;i++){
				PB_array[i] = -1;
			}
		//printf("active task %d\n",num_active_task);
		OSSchedUnlock();
		OSTimeDlyHMSM(0, 0, 3, 0);
	}
}


// Function for occupying the processor for the specified number of clock ticks
// to simulate custom delay while keeping the task in the processor
void custom_delay(int ticks) {
    INT32U cur_tick;
    ticks--;
    cur_tick = OSTimeGet();
    while (ticks > 0) {
         if (OSTimeGet() > cur_tick) {
            ticks--;
            cur_tick = OSTimeGet();
         }  
    }
}
