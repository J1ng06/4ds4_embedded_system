// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

// Definition of semaphore for PBs
OS_EVENT *PBSemaphore[4];

// Definition of Mutex for LCD
//OS_EVENT *LCDMutex;
OS_EVENT *LED_R_Mutex;
OS_EVENT *LED_G_Mutex;
OS_EVENT *SWITCHAMutex;
OS_EVENT *SWITCHBMutex;

// Definition of task stacks
OS_STK	  initialize_task_stk[TASK_STACKSIZE];
OS_STK	  task_launcher_stk[TASK_STACKSIZE];

OS_STK	  custom_task_stk[NUM_TASK][TASK_STACKSIZE];
OS_TCB	  custom_task_tcb[NUM_TASK];

extern alt_up_character_lcd_dev *lcd_0;

// Local function prototypes
void custom_delay(int);

// Custom task 0
// It has a high priority to monitor PB0
// And it display OS info when PB0 is pressed
void custom_task_0(void* pdata) {
	INT8U return_code = OS_NO_ERR;

	int i;

	while (1) {
		// Wait for PB0
		OSSemPend(PBSemaphore[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("-Waiting for SWTICH A Mutex (Task 0)...\n");
		OSMutexPend(SWITCHAMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH A Mutex obtained (Task 0)...\n");



		printf("-Waiting for LED RED Mutex (Task 0)...\n");
		OSMutexPend(LED_R_Mutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-LED RED Mutex obtained (Task 0)...\n");


		IOWR(LED_RED_O_BASE, 0, IORD(SWITCH_GRPA_I_BASE, 0)&0x1ff);

		OSTimeDly(THREE_AND_HALF_SEC);

		IOWR(LED_RED_O_BASE, 0, 0);

		printf("-Releasing SWTICH A Mutex (Task 0)...\n");
		return_code = OSMutexPost(SWITCHAMutex);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR A Mutex released (Task 0)...\n");

		printf("-Releasing LED RED Mutex (Task 0)...\n");
		return_code = OSMutexPost(LED_R_Mutex);
		alt_ucosii_check_return_code(return_code);
		printf("-LED RED Mutex released (Task 0)...\n");

	}
}

// Custom task 1
// It monitors PB1
// And it display a message on LCD when PB1 is pressed
void custom_task_1(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	alt_8 flag = 0;

	while (1) {
		// Wait for PB1
		OSSemPend(PBSemaphore[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("-Waiting for SWTICH A Mutex (Task 1)...\n");
		OSMutexPend(SWITCHAMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR A Mutex obtained (Task 1)...\n");

		printf("-Waiting for LED GREEN Mutex (Task 1)...\n");
		OSMutexPend(LED_G_Mutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-LED GREEN Mutex obtained (Task 1)...\n");


		IOWR(LED_GREEN_O_BASE, 0, IORD(SWITCH_GRPA_I_BASE, 0)&0x1ff);

		OSTimeDly(THREE_AND_HALF_SEC);

		IOWR(LED_GREEN_O_BASE, 0, 0);

		printf("-Releasing SWTICH A Mutex (Task 1)...\n");
		return_code = OSMutexPost(SWITCHAMutex);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR A Mutex released (Task 1)...\n");

		printf("-Releasing LED GREEN Mutex (Task 1)...\n");
		return_code = OSMutexPost(LED_G_Mutex);
		alt_ucosii_check_return_code(return_code);
		printf("-LED GREEN Mutex released (Task 1)...\n");
	}
}

// Custom task 2
// It monitors PB2
// And it display a message on LCD when PB2 is pressed
void custom_task_2(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	alt_8 flag = 0;

	while (1) {
		// Wait for PB2
		OSSemPend(PBSemaphore[2], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("-Waiting for SWTICH B Mutex (Task 2)...\n");
		OSMutexPend(SWITCHBMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR B Mutex obtained (Task 2)...\n");

		printf("-Waiting for LED RED Mutex (Task 2)...\n");
		OSMutexPend(LED_R_Mutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-LED RED Mutex obtained (Task 2)...\n");


		IOWR(LED_RED_O_BASE, 0, IORD(SWITCH_GRPB_I_BASE, 0) & 0xff);
		OSTimeDly(TWO_AND_HALF_SEC);

		IOWR(LED_RED_O_BASE, 0, 0);

		printf("-Releasing SWTICH B Mutex (Task 2)...\n");
		return_code = OSMutexPost(SWITCHBMutex);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR B Mutex released (Task 2)...\n");

		printf("-Releasing LED RED Mutex (Task 2)...\n");
		return_code = OSMutexPost(LED_R_Mutex);
		alt_ucosii_check_return_code(return_code);
		printf("-LED RED Mutex released (Task 2)...\n");
	}
}

// Custom task 3
// It monitors PB3
// And it erases all characters on LCD when PB3 is pressed
void custom_task_3(void* pdata) {
	INT8U return_code = OS_NO_ERR;

	while (1) {
		// Wait for PB3
		OSSemPend(PBSemaphore[3], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("-Waiting for SWTICHA Mutex (Task 3)...\n");
		OSMutexPend(SWITCHBMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR A Mutex obtained (Task 3)...\n");

		printf("-Waiting for LED GREEN Mutex (Task 3)...\n");
		OSMutexPend(LED_G_Mutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("-LED GREEN Mutex obtained (Task 3)...\n");


		IOWR(LED_GREEN_O_BASE, 0, IORD(SWITCH_GRPB_I_BASE, 0) & 0xff);
		OSTimeDly(TWO_AND_HALF_SEC);

		IOWR(LED_GREEN_O_BASE, 0, 0);

		printf("-Releasing SWTICH A Mutex (Task 3)...\n");
		return_code = OSMutexPost(SWITCHBMutex);
		alt_ucosii_check_return_code(return_code);
		printf("-SWTICH GR A Mutex released (Task 3)...\n");

		printf("-Releasing LED GREEN Mutex (Task 3)...\n");
		return_code = OSMutexPost(LED_G_Mutex);
		alt_ucosii_check_return_code(return_code);
		printf("-LED GREEN Mutex released (Task 3)...\n");
	}
}

// Task launcher
// It creates all the custom tasks
// And then it deletes itself
void task_launcher(void *pdata) {
	INT8U return_code = OS_NO_ERR;

	#if OS_CRITICAL_METHOD == 3
		OS_CPU_SR cpu_sr;
	#endif

	printf("Starting task launcher...\n");
	while (1) {
		OS_ENTER_CRITICAL();
		
		IOWR(LED_GREEN_O_BASE, 0, 0);
		IOWR(LED_RED_O_BASE, 0, 0);
		
		printf("Creating tasks...\n");

		return_code = OSTaskCreateExt(custom_task_0,
			NULL,
			(void *)&custom_task_stk[0][TASK_STACKSIZE-1],
			CUSTOM_TASK_0_PRIORITY,
			CUSTOM_TASK_0_PRIORITY,
			&custom_task_stk[0][0],
			TASK_STACKSIZE,
			&custom_task_tcb[0],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(custom_task_1,
			NULL,
			(void *)&custom_task_stk[1][TASK_STACKSIZE-1],
			CUSTOM_TASK_1_PRIORITY,
			CUSTOM_TASK_1_PRIORITY,
			&custom_task_stk[1][0],
			TASK_STACKSIZE,
			&custom_task_tcb[1],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(custom_task_2,
			NULL,
			(void *)&custom_task_stk[2][TASK_STACKSIZE-1],
			CUSTOM_TASK_2_PRIORITY,
			CUSTOM_TASK_2_PRIORITY,
			&custom_task_stk[2][0],
			TASK_STACKSIZE,
			&custom_task_tcb[2],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(custom_task_3,
			NULL,
			(void *)&custom_task_stk[3][TASK_STACKSIZE-1],
			CUSTOM_TASK_3_PRIORITY,
			CUSTOM_TASK_3_PRIORITY,
			&custom_task_stk[3][0],
			TASK_STACKSIZE,
			&custom_task_tcb[3],
			0);
		alt_ucosii_check_return_code(return_code);


		printf("Finish creating tasks...\n");

		printf("PB 0: Task 0\n");
		printf("PB 1: Task 1\n");
		printf("PB 2: Task 2\n");
		printf("PB 3: Task 3\n");
		printf("\n");

		// Delay for 1 sec
		OSTimeDlyHMSM(0, 0, 1, 0);

		// Delete itself
		return_code = OSTaskDel(OS_PRIO_SELF);
		alt_ucosii_check_return_code(return_code);

		OS_EXIT_CRITICAL();
	}
}

// Function for occupying the processor for the specified number of clock ticks
// to simulate custom delay while keeping the task in the processor
void custom_delay(int ticks) {
    INT32U cur_tick;
    ticks--;
    cur_tick = OSTimeGet();
    while (ticks > 0) {
         if (OSTimeGet() > cur_tick) {
            ticks--;
            cur_tick = OSTimeGet();
         }  
    }
}
