// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

// Definition of semaphore for PBs
OS_EVENT *PBSemaphore[4];

// Definition of Mutex for LCD
OS_EVENT *LCDMutex;

//Definition of other Mutex's
OS_EVENT *SW_AMutex;
OS_EVENT *SW_BMutex;
OS_EVENT *LED_RMutex;
OS_EVENT *LED_GMutex;

// Definition of task stacks
OS_STK	  initialize_task_stk[TASK_STACKSIZE];
OS_STK	  task_launcher_stk[TASK_STACKSIZE];

OS_STK	  custom_task_stk[NUM_TASK][TASK_STACKSIZE];
OS_TCB	  custom_task_tcb[NUM_TASK];

extern alt_up_character_lcd_dev *lcd_0;

// Local function prototypes
void custom_delay(int);

// Custom task 0
// It has a high priority to monitor PB0
// And it display OS info when PB0 is pressed
void custom_task_0(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	int switchValue;
	//OS_TCB tcb_data;

	//OS_MUTEX_DATA mutex_data;
	//OS_SEM_DATA sem_data;
	//int i;

	while (1) {
		// Wait for PB0
		OSSemPend(PBSemaphore[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("Task 0 waiting on Switch Group A Mutex\n");
		OSMutexPend(SW_AMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 0 obtains Switch Group A Mutex\n");

		printf("Task 0 waiting on Red LED Mutex\n");
		OSMutexPend(LED_RMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 0 obtains Red LED Mutex\n");

		switchValue = (IORD(SWITCH_GRPA_I_BASE,0) & 0x1FF);
		IOWR(LED_RED_O_BASE,0,switchValue & 0x1FF);

		custom_delay(THREE_HALF_SECONDS);

		printf("Task 0 releasing Switch Group A Mutex\n");
		return_code = OSMutexPost(SW_AMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 0 released Switch Group A Mutex\n");

		printf("Task 0 releasing Red LED Mutex\n");
		return_code = OSMutexPost(LED_RMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 0 released Red LED Mutex\n");

		OSTimeDlyHMSM(0, 0, 0, 100);
	}
}

// Custom task 1
// It monitors PB1
// And it display a message on LCD when PB1 is pressed
void custom_task_1(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	int switchValue;

	while (1) {
		// Wait for PB1
		// Task will be suspended while waiting
		OSSemPend(PBSemaphore[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("Task 1 waiting on Switch Group A Mutex\n");
		OSMutexPend(SW_AMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 1 obtains Switch Group A Mutex\n");

		printf("Task 1 waiting on Green LED Mutex\n");
		OSMutexPend(LED_GMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 1 obtains Green LED Mutex\n");

		switchValue = (IORD(SWITCH_GRPA_I_BASE,0) & 0x1FF);
		IOWR(LED_GREEN_O_BASE,0,switchValue & 0x1FF);

		custom_delay(THREE_HALF_SECONDS);

		printf("Task 1 releasing Switch Group A Mutex\n");
		return_code = OSMutexPost(SW_AMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 1 released Switch Group A Mutex\n");

		printf("Task 1 releasing Green LED Mutex\n");
		return_code = OSMutexPost(LED_GMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 1 released Green LED Mutex\n");

		OSTimeDlyHMSM(0, 0, 0, 100);


	}
}

// Custom task 2
// It monitors PB2
// And it display a message on LCD when PB2 is pressed
void custom_task_2(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	int switchValue;

	while (1) {
		// Wait for PB2
		// Task will be suspended while waiting
		OSSemPend(PBSemaphore[2], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("Task 2 waiting on Switch Group B Mutex\n");
		OSMutexPend(SW_BMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 2 obtains Switch Group B Mutex\n");

		printf("Task 2 waiting on Red LED Mutex\n");
		OSMutexPend(LED_RMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 2 obtains Red LED Mutex\n");

		switchValue = (IORD(SWITCH_GRPB_I_BASE,0) & 0xFF);
		IOWR(LED_RED_O_BASE,0,switchValue & 0xFF);

		custom_delay(TWO_HALF_SECONDS);

		printf("Task 2 releasing Switch Group B Mutex\n");
		return_code = OSMutexPost(SW_BMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 2 released Switch Group B Mutex\n");

		printf("Task 2 releasing Red LED Mutex\n");
		return_code = OSMutexPost(LED_RMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 2 released Red LED Mutex\n");

		OSTimeDlyHMSM(0, 0, 0, 100);


	}
}

// Custom task 3
// It monitors PB3
// And it erases all characters on LCD when PB3 is pressed
void custom_task_3(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	int switchValue;

	while (1) {
		// Wait for PB3
		// Task will be suspended while waiting
		OSSemPend(PBSemaphore[3], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("Task 3 waiting on Switch Group B Mutex\n");
		OSMutexPend(SW_BMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 3 obtains Switch Group B Mutex\n");

		printf("Task 3 waiting on Green LED Mutex\n");
		OSMutexPend(LED_GMutex, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		printf("Task 3 obtains Green LED Mutex\n");

		switchValue = (IORD(SWITCH_GRPB_I_BASE,0) & 0xFF);
		IOWR(LED_GREEN_O_BASE,0,switchValue & 0xFF);

		custom_delay(TWO_HALF_SECONDS);

		printf("Task 3 releasing Switch Group B Mutex\n");
		return_code = OSMutexPost(SW_BMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 3 released Switch Group B Mutex\n");

		printf("Task 3 releasing Green LED Mutex\n");
		return_code = OSMutexPost(LED_GMutex);
		alt_ucosii_check_return_code(return_code);
		printf("Task 3 released Green LED Mutex\n");

		OSTimeDlyHMSM(0, 0, 0, 100);
	}
}

// Task launcher
// It creates all the custom tasks
// And then it deletes itself
void task_launcher(void *pdata) {
	INT8U return_code = OS_NO_ERR;

	#if OS_CRITICAL_METHOD == 3
		OS_CPU_SR cpu_sr;
	#endif

	printf("Starting task launcher...\n");
	while (1) {
		OS_ENTER_CRITICAL();
		
		IOWR(LED_GREEN_O_BASE, 0, IORD(SWITCH_GRPA_I_BASE, 0));
		IOWR(LED_RED_O_BASE, 0, IORD(SWITCH_GRPB_I_BASE, 0));
		
		printf("Creating tasks...\n");

		return_code = OSTaskCreateExt(custom_task_0,
			NULL,
			(void *)&custom_task_stk[0][TASK_STACKSIZE-1],
			CUSTOM_TASK_0_PRIORITY,
			CUSTOM_TASK_0_PRIORITY,
			&custom_task_stk[0][0],
			TASK_STACKSIZE,
			&custom_task_tcb[0],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(custom_task_1,
			NULL,
			(void *)&custom_task_stk[1][TASK_STACKSIZE-1],
			CUSTOM_TASK_1_PRIORITY,
			CUSTOM_TASK_1_PRIORITY,
			&custom_task_stk[1][0],
			TASK_STACKSIZE,
			&custom_task_tcb[1],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(custom_task_2,
			NULL,
			(void *)&custom_task_stk[2][TASK_STACKSIZE-1],
			CUSTOM_TASK_2_PRIORITY,
			CUSTOM_TASK_2_PRIORITY,
			&custom_task_stk[2][0],
			TASK_STACKSIZE,
			&custom_task_tcb[2],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(custom_task_3,
			NULL,
			(void *)&custom_task_stk[3][TASK_STACKSIZE-1],
			CUSTOM_TASK_3_PRIORITY,
			CUSTOM_TASK_3_PRIORITY,
			&custom_task_stk[3][0],
			TASK_STACKSIZE,
			&custom_task_tcb[3],
			0);
		alt_ucosii_check_return_code(return_code);


		printf("Finish creating tasks...\n");

		printf("PB 0: Launch Task 0\n");
		printf("PB 1: Launch Task 1\n");
		printf("PB 2: Launch Task 2\n");
		printf("PB 3: Launch Task 3\n");
		printf("\n");

		// Delay for 1 sec
		OSTimeDlyHMSM(0, 0, 1, 0);

		// Delete itself
		return_code = OSTaskDel(OS_PRIO_SELF);
		alt_ucosii_check_return_code(return_code);

		OS_EXIT_CRITICAL();
	}
}

// Function for occupying the processor for the specified number of clock ticks
// to simulate custom delay while keeping the task in the processor
void custom_delay(int ticks) {
    INT32U cur_tick;
    ticks--;
    cur_tick = OSTimeGet();
    while (ticks > 0) {
         if (OSTimeGet() > cur_tick) {
            ticks--;
            cur_tick = OSTimeGet();
         }  
    }
}
