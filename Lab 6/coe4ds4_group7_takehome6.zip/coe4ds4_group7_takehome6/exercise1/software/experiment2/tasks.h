// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#ifndef __task_H__
#define __task_H__

// Size of stack for each task
#define   TASK_STACKSIZE       2048

// Definition of Task Priorities
#define INITIALIZE_TASK_PRIORITY   6
#define CUSTOM_SCHEDULER_PRIORITY  9
#define TASK_START_PRIORITY       10

#define SHAYAN		6
#define NAZIM		5
#define MUKHTAR		7
#define QUASIMUDDIN	11

#define PERIODIC_TASK_1_PRIORITY	12
#define PERIODIC_TASK_2_PRIORITY	13

#define MY_NON_PREEMPTIVE_SCH 1	//1 is preempting is turned off, 0 is preempting on

// Number of custom tasks
#define NUM_TASK 2

// Global function
void custom_scheduler(void *pdata);

#endif
