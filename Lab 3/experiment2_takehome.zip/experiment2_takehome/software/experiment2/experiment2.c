// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

int main()
{
	volatile PS2_buffer_struct PS2_buffer_data;

	printf("Start main...\n");

	PS2_buffer_data.buffer_flush = 0;
	PS2_buffer_data.cur_buf_length = 0;
	PS2_buffer_data.caps = 0;
	PS2_buffer_data.key_state[0]=0;
	PS2_buffer_data.key_state[1]=0;
	PS2_buffer_data.key_state[2]=0;
	PS2_buffer_data.key_state[3]=0;
	PS2_buffer_data.key_state[4]=0;
	PS2_buffer_data.key_state[5]=0;
	PS2_buffer_data.string_buffer[0] = '\0';
	PS2_buffer_data.string_buffer[1] = '\0';
	PS2_buffer_data.string_buffer[2] = '\0';
	PS2_buffer_data.string_buffer[3] = '\0';
	PS2_buffer_data.string_buffer[4] = '\0';
	PS2_buffer_data.string_buffer[5] = '\0';
	PS2_buffer_data.string_buffer[6] = '\0';
	PS2_buffer_data.string_buffer[7] = '\0';
	PS2_buffer_data.string_buffer[8] = '\0';
	PS2_buffer_data.string_buffer[9] = '\0';

	init_PS2_irq(&PS2_buffer_data);
	printf("PS2 IRQ initialized...\n");

	IOWR(LED_GREEN_O_BASE, 0, 0x0);
	IOWR(LED_RED_O_BASE, 0, 0x0);
	
	printf("Switch value: %X\n", IORD(SWITCH_I_BASE, 0));
		
	while (1) {
		if (PS2_buffer_data.buffer_flush == 1) {
			printf("%s", PS2_buffer_data.string_buffer);
			PS2_buffer_data.buffer_flush = 0;
			PS2_buffer_data.string_buffer[0] = '\0';
			PS2_buffer_data.cur_buf_length = 0;
		}
	};
	
	return 0;
}
