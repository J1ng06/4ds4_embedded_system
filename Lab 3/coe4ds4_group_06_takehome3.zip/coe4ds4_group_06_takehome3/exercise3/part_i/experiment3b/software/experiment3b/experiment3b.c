// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "sys/alt_alarm.h"
#include "alt_types.h"
#include "system.h"
#include "altera_avalon_performance_counter.h"
#include "md5.h"

#define ARRAY_SIZE 500

// For performance counter
void *performance_name = PERFORMANCE_COUNTER_0_BASE;

int main()
{ 
	int i,j;
	md5_byte_t digest[16];
	md5_byte_t *message[7];
	int sum = 0;
	message[0] = "";
	message[1] = "a";
	message[2] = "abc";
	message[3] = "message digest";
	message[4] = "abcdefghijklmnopqrstuvwxyz";
	message[5] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	message[6] = "12345678901234567890123456789012345678901234567890123456789012345678901234567890";
	
	md5_state_t state;
	for (i = 0;i<7;i++){

		// For performance counter
		PERF_RESET(PERFORMANCE_COUNTER_0_BASE);

		// Start the performance counter
		PERF_START_MEASURING(performance_name);

		// Start performance counter
		PERF_BEGIN(performance_name, 1);
		//printf("string length %d\n",strlen(message[i]));
		md5_init(&state);
		md5_append(&state, (const md5_byte_t *)message[i],strlen(message[i]));
		md5_finish(&state, digest);
		/*for(j = 0; j<16;j++){
			printf("%02x",digest[j]);
		}
		printf("\n");*/
		// Stop performance counter
		PERF_END(performance_name, 1);
	
		// Start the performance counter
		PERF_STOP_MEASURING(performance_name);
	sum = sum + perf_get_section_time(performance_name, 1);
	}
	printf("PC average: %d\n", sum/7);
  /* Event loop never exits. */
  while (1);

  return 0;
}
