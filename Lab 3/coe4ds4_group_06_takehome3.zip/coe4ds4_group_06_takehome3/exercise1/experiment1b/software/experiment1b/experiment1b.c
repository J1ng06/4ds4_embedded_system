// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada


#include "define.h"

alt_u16 disp_seven_seg(alt_u8 val) {
    switch (val) {
        case  0 : return 0x40;
        case  1 : return 0x79;
        case  2 : return 0x24;
        case  3 : return 0x30;
        case  4 : return 0x19;
        case  5 : return 0x12;
        case  6 : return 0x02;
        case  7 : return 0x78;
        case  8 : return 0x00;
        case  9 : return 0x18;
        case 10 : return 0x08;
        case 11 : return 0x03;
        case 12 : return 0x46;
        case 13 : return 0x21;
        case 14 : return 0x06;
        case 15 : return 0x0e;
        default : return 0x7f;
    }
}

int main()
{
	elevator_data elevator;
	init_button_irq(&elevator);
	init_counter_irq(&elevator);
	init_counter_1_irq(&elevator);
	init_switch_irq(&elevator);
	
	printf("Exercise 1!\n");

	elevator.current_floor = 0;
	elevator.direction = stay; //  1 means going up, 0 means staying, -1 means going down
	elevator.floor_requested = 0;
	elevator.stationary = true;
	elevator.keep_door_open = false;
	elevator.door_counter_expire = true;

	while (1){
		IOWR(LED_RED_O_BASE, 0, elevator.floor_requested);
		IOWR(SEVEN_SEGMENT_N_O_0_BASE, 0, disp_seven_seg(elevator.current_floor));
		if (elevator.stationary == true){
			if(elevator.direction == stay){
				if (elevator.door_counter_expire == true && elevator.keep_door_open == false){
					if(elevator.floor_requested != 0){
						if (elevator.floor_requested >> elevator.current_floor == 1){
							printf("The elevator is already on Floor %d\n", elevator.current_floor);
							elevator.floor_requested = elevator.floor_requested & ~(0x1 << elevator.current_floor);
							reset_counter_1(&elevator);
						}else if(elevator.floor_requested >> elevator.current_floor != 0){
							//printf("3");
							//printf("Current Floor = %d\n\n", elevator.current_floor);
							elevator.direction = up;
							elevator.stationary = false;
							reset_counter(&elevator);
						}else{
							elevator.direction = down;
							elevator.stationary = false;
							//printf("5");
							reset_counter(&elevator);
							//printf("The Elevator is going down");
							//printf("Current Floor = %d\n\n", elevator.current_floor);
						}
						//printf("5");
					}

				}
			}else{
				if((elevator.floor_requested >> elevator.current_floor) & (0x1) == 1){
					//reach requested floor
					elevator.floor_requested = elevator.floor_requested & ~(0x1 << elevator.current_floor);
					elevator.direction = stay;

					reset_counter_1(&elevator);
				}else if ((elevator.door_counter_expire == true && elevator.keep_door_open == false) && elevator.direction ==up){
					if (elevator.floor_requested >> elevator.current_floor!= 0){//check if any upper floor
						//printf("1");
						elevator.stationary = false;
						reset_counter(&elevator);
					}else if (elevator.floor_requested != 0){//check if any lower floor
						elevator.direction = down;
						elevator.stationary = false;
						//printf("2");
						reset_counter(&elevator);
					}else{
						elevator.direction = stay;
					}
				}else if ((elevator.door_counter_expire == true && elevator.keep_door_open == false) && elevator.direction ==down){
					if ((elevator.floor_requested & ((~(0xFFF<< elevator.current_floor)) & 0xFFF))!= 0){//check if any lower floor
						//printf("3");
						elevator.stationary = false;
						reset_counter(&elevator);
					}else if (elevator.floor_requested != 0){//check if any upper floor
						elevator.direction = up;
						elevator.stationary = false;
						//printf("4");
						reset_counter(&elevator);
					}else{
						elevator.direction = stay;
					}
				}
			}
		}
	}
	return 0;
}
