#ifndef __SWITCH_H__
#define __SWITCH_H__

void handle_switch_interrupts();
void init_switch_irq(elevator_data *);

#endif
