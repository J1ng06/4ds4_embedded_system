#include "define.h"

//extern volatile int floor_requested;
void handle_switch_interrupts(elevator_data *elevator){
	elevator->floor_requested = elevator->floor_requested | (IORD(SWITCH_I_BASE, 3) & 0xFFF);
	//printf("requested floor = %d",elevator->floor_requested);

	IOWR(SWITCH_I_BASE, 3, 0x0);
}

void init_switch_irq(elevator_data *elevator) {
  IOWR(SWITCH_I_BASE, 2, 0xFFF); //0x18FFF?
  IOWR(SWITCH_I_BASE, 3, 0x0);

  // Register the interrupt handler
  alt_irq_register(SWITCH_I_IRQ, (void*)elevator, (void*)handle_switch_interrupts );
}
