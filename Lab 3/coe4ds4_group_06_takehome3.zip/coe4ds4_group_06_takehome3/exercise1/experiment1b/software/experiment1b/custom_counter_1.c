#include "define.h"

// ISR when the counter is expired
void handle_counter_1_expire_interrupts(elevator_data *elevator)
{
	elevator->door_counter_expire = true;
	if (elevator->keep_door_open == false){
	printf("Door is now closing.\n");}
	IOWR(CUSTOM_COUNTER_COMPONENT_1_BASE, 2, 0);
}

void reset_counter_1(elevator_data *elevator) {
	elevator->door_counter_expire = false;
	IOWR(CUSTOM_COUNTER_COMPONENT_1_BASE, 1, 1);
	IOWR(CUSTOM_COUNTER_COMPONENT_1_BASE, 1, 0);

	IOWR(CUSTOM_COUNTER_COMPONENT_1_BASE, 2, 0);
	printf("Door is now open.\n");
}

int read_counter_1() {
	return IORD(CUSTOM_COUNTER_COMPONENT_1_BASE, 0);
}

int read_counter_1_interrupt() {
	return IORD(CUSTOM_COUNTER_COMPONENT_1_BASE, 2);
}

void load_counter_1_config(int config) {
	printf("Loading door counter config %d\n", config);

	IOWR(CUSTOM_COUNTER_COMPONENT_1_BASE, 3, config);
}

// Function for initializing the ISR of the Counter
void init_counter_1_irq(elevator_data *elevator) {
	IOWR(CUSTOM_COUNTER_COMPONENT_1_BASE, 2, 0);

	alt_irq_register(CUSTOM_COUNTER_COMPONENT_1_IRQ, (void*)elevator, (void*)handle_counter_1_expire_interrupts );
}
