// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

void KEY0_Pressed() {
	//reset_counter();
}

void KEY1_Pressed(elevator_data *elevator) {
	if (elevator->stationary == true && elevator->door_counter_expire == true && elevator->keep_door_open == false){
		if((((IORD(PUSH_BUTTON_I_BASE,0))>>1)& 0x1) == 0){
		load_counter_1_config((IORD(SWITCH_I_BASE, 0) & 0x18000) >> 15);
		}
	}
}

void KEY2_Pressed(elevator_data *elevator) {
	if (elevator->stationary == true && elevator->door_counter_expire == true && elevator->keep_door_open == false){
		if((((IORD(PUSH_BUTTON_I_BASE,0))>>2)& 0x1) == 0){
		load_counter_config((IORD(SWITCH_I_BASE, 0) & 0x18000) >> 15);
		}
	}
	//printf("Counter value = %d\n", read_counter());
}

void KEY3_Pressed(elevator_data *elevator) {
	if (elevator->stationary == true || elevator->door_counter_expire == false ||elevator->keep_door_open == true){
		//printf("key 3 reg 0%d\n",(IORD(PUSH_BUTTON_I_BASE,0)));
		//printf("key 3 reg 0 %d\n",(IORD(PUSH_BUTTON_I_BASE,0)));
		if(((IORD(PUSH_BUTTON_I_BASE,0)>>3)& 0x1) == 0){//can't detect properly
			elevator->keep_door_open = true;
			printf("Door is kept open\n");
		}else{
			//printf("key 3 reg 0 %d\n",(IORD(PUSH_BUTTON_I_BASE,0)));
			elevator->keep_door_open = false;
			printf("Door is not kept open\n");
		}

	}
}

// ISR when any PB is pressed
void handle_button_interrupts(elevator_data *elevator)
{
	IOWR(LED_GREEN_O_BASE, 0, IORD(PUSH_BUTTON_I_BASE, 3)*IORD(PUSH_BUTTON_I_BASE, 3));
	
	switch(IORD(PUSH_BUTTON_I_BASE, 3)) {
	case 1: KEY0_Pressed(); break;
	case 2: KEY1_Pressed(elevator); break;
	case 4: KEY2_Pressed(elevator); break;
	case 8: KEY3_Pressed(elevator); break;
	}
	IOWR(PUSH_BUTTON_I_BASE, 3, 0x0);
}

// Function for initializing the ISR of the PBs
// The PBs are setup to generate interrupt on falling edge,
// and the interrupt is captured when the edge comes
void init_button_irq(elevator_data *elevator) {
  // Enable all 4 button interrupts
  IOWR(PUSH_BUTTON_I_BASE, 2, BUTTON_INT_MASK);

  // Reset the edge capture register
  IOWR(PUSH_BUTTON_I_BASE, 3, 0x0);

  // Register the interrupt handler
  alt_irq_register(PUSH_BUTTON_I_IRQ, (void *)elevator, (void*)handle_button_interrupts );
}
