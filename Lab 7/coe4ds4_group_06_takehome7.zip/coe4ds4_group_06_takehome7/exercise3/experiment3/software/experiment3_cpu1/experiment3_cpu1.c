// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include <stdio.h>
#include <string.h>
#include "sys/alt_alarm.h"
#include "alt_types.h"
#include "sys/alt_irq.h"
#include "system.h"
#include "nios2.h"
#include "io.h"
#include "altera_avalon_mutex.h"
#include "altera_avalon_performance_counter.h"

#define MESSAGE_START_CALC		  5
#define MESSAGE_WAITING_DATA	  4
#define MESSAGE_RESULT_READY	  3
#define MESSAGE_WAITING_B_ELEMENT 2
#define MESSAGE_WAITING_A_ELEMENT 1

#define NO_MESSAGE 0

#define LOCK_SUCCESS 0
#define LOCK_FAIL 1000

#define MESSAGE_BUFFER_BASE MESSAGE_BUFFER_RAM_BASE

#define MS_DELAY 1

// Message buffer structure
typedef struct {
	char flag;
	int B_buf[32][8];
	//int testing_data;
	// the buffer can hold up to 4KBytes data
	int A_buf[16][32]; //should use 16*32 2-D array buffer, move the data into CPU2 3 times
} message_buffer_struct;

// For performance counter
void *performance_name = CPU1_PERFORMANCE_COUNTER_BASE;

// Global functions
void handle_cpu1_button_interrupts(int *generate) {
//	int A[1024], B[1024];
	// Set the flag that a message has been put in the buffer
	// And this message should be displayed on UART connected to CPU1
//	int A_max_value, A_min_value,B_max_value,B_min_value;
//	// Get the seed from the switches
//	//switches = IORD(SWITCH_I_BASE, 0);
//	int i;
//	//if ((IORD(CPU1_PB_BUTTON_I_BASE, 3) & 0x3) != 0){
//	printf("interrupt\n");
//
//		A_max_value = -10000;
//		A_min_value = 10000;
//		B_max_value = -400;
//		B_min_value = 400;
//		// Start generation
//		for (i = 0; i < 1024; i++) {
//			A[i] = (rand() % 20001) - 10000;
//			B[i] = (rand() % 801) - 400;
//			// For verification
//			if (A[i] > A_max_value) A_max_value = A[i];
//			if (A[i] < A_min_value) A_min_value = A[i];
//			if (B[i] > B_max_value) B_max_value = B[i];
//			if (B[i] < B_min_value) B_min_value = B[i];
//		}
//		printf('%d, %d, %d , %d\n',A_max_value,A_min_value,B_max_value,B_min_value);
//
//	IOWR(CPU1_PB_BUTTON_I_BASE, 3, 0x0);
	*generate = 1;
	//printf("interrupt %d\n", *generate);
	switch(IORD(CPU1_PB_BUTTON_I_BASE, 3)) {
			case 1: IOWR(CPU1_LED_RED_O_BASE, 0, 1); break;
			case 2: IOWR(CPU1_LED_RED_O_BASE, 0, 4); break;

	// case 1: alt_up_character_lcd_string((alt_up_character_lcd_dev *)lcd_0, "CPU12PB0 pressed"); break;
	// case 2: alt_up_character_lcd_string((alt_up_character_lcd_dev *)lcd_0, "CPU12PB1 pressed"); break;
	}

	IOWR(CPU1_PB_BUTTON_I_BASE, 3, 0x0);
}

// The main function
int main() {
	// Pointer to our mutex device
	alt_mutex_dev* mutex = NULL;

	// Local variables
	unsigned int id;
	unsigned int value;
	unsigned int count = 0;
	unsigned int ticks_at_last_message;
	int switches;
	int generate = 0;
	int ready = 0;
	message_buffer_struct *message;
	int A[32][32], B[32][32],C[32][32];
	int A_max_value;
	int A_min_value;
	int B_max_value;
	int B_min_value;
	int i,j,k;
	int result_CPU1 = 0;
	int A_element_count = 0; // element in a row of A
	int row_count = 16;	// send Row 16 to 31 to B
	int calc = 0;
	int B_column_count = 0;
	int B_row_count = 0;
	int start_transmit_A = 0;
	int start_transmit_B = 0;
    int C_CPU2[16][32];
    int done_calculation = 1;
//	for (i = 0; i < 1024; i++) {
//		A[i] = B[i] = 0;
//	}
	// For performance counter
	PERF_RESET(CPU1_PERFORMANCE_COUNTER_BASE);

	// Reading switches 15-8 for CPU1
	switches = IORD(CPU1_SWITCH_I_BASE, 0);
	
	// Enable all button interrupts
	IOWR(CPU1_PB_BUTTON_I_BASE, 2, 0x3);
	IOWR(CPU1_PB_BUTTON_I_BASE, 3, 0x0);
	alt_irq_register(CPU1_PB_BUTTON_I_IRQ, &generate, (void*)handle_cpu1_button_interrupts );
  
	// Get our processor ID (add 1 so it matches the cpu name in SOPC Builder)
	NIOS2_READ_CPUID(id);

	printf("COE4DS4 Winter15\n");
	printf("Lab7     exp.  3\n\n");

	// Value can be any non-zero value
	value = 1;

	// Initialize the message buffer location
	message = (message_buffer_struct*)MESSAGE_BUFFER_BASE;

	// Okay, now we'll open the real mutex
	// It's not actually a mutex to share the jtag_uart, but to share a message
	// buffer which CPU1 is responsible for reading and printing to the jtag_uart.
	mutex = altera_avalon_mutex_open(MESSAGE_BUFFER_MUTEX_NAME);

	// We'll use the system clock to keep track of our delay time.
	// Here we initialize delay tracking variable.
	ticks_at_last_message = alt_nticks();

	printf("Press either of the buttons connected to CPU1 to start generation\n");
	if (mutex) {
		message->flag = NO_MESSAGE;
		PERF_START_MEASURING(performance_name);
		while(1) {
			switches = IORD(CPU1_SWITCH_I_BASE,0);
			srand(switches);
			if (generate == 1 && done_calculation == 1){
				PERF_BEGIN(performance_name, 6);
				printf("Random Array Generation Start!\n");
				PERF_BEGIN(performance_name, 1);
				//A_max_value = -10000;
				//A_min_value = 10000;
				//B_max_value = -400;
				//B_min_value = 400;
				// Start generation
				for (i = 0; i < 32; i++) {
					for (j = 0; j< 32; j++){
						A[i][j] = (rand() % 20001) - 10000; //20001 or 20000?
						B[i][j] = (rand() % 801) - 400;	//401 or 400?
						// For verification
						//if (A[i][j] > A_max_value) A_max_value = A[i][j];
						//if (A[i][j] < A_min_value) A_min_value = A[i][j];
						//if (B[i][j] > B_max_value) B_max_value = B[i][j];
						//if (B[i][j] < B_min_value) B_min_value = B[i][j];
					}
				}
//				for (i = 0; i < 32; i++) {
//						//printf("A Row %d\n", i);
//					for (j = 0; j< 32; j++){
//						printf("%d ", A[i][j]);
//					}
//					printf("\n");
//				}
//				printf("\n\n");
//				for (i = 0; i < 32; i++) {
//					//printf("B Row %d\n", i);
//					for (j = 0; j< 32; j++){
//						printf("%d ", B[i][j]);
//					}
//					printf("\n");
//				}
				generate = 0;
				done_calculation = 0;
				PERF_END(performance_name, 1);
				printf("Random Array Generation Done!\n");
				printf("\nPress either of the buttons connected to CPU2 to start calculation\n");
				//printf("A_max %d, A_min %d, B_max %d , B_min %d\n\n",A_max_value,A_min_value,B_max_value,B_min_value);
				//printf('%d, %d, %d , %d\n',A[i],A[i],B[i],B[i]);
			}
			if (calc == 1 && done_calculation == 0){
				//PERF_BEGIN(performance_name, 3);
				for (i = 0; i<16;i++){
					for (j = 0; j<32;j++){
						result_CPU1 = 0;
						for (k = 0; k < 32;k++){
							result_CPU1 += A[i][k]*B[k][j];
						}
						C[i][j] = result_CPU1;
					}
				}
				PERF_END(performance_name, 3);
//				for (i = 0; i < 32; i++) {
//					printf("Row %d\n", i);
//					for (j = 0; j< 32; j++){
//						printf("%d ", C[i][j]);
//					}
//					printf("\n");
//				}
				// reset
				B_column_count = 0;
				calc = 0;
			}
			if(ready == 1 && done_calculation == 0){
			// See if it's time to send a message yet
				if (alt_nticks() >= (ticks_at_last_message + ((alt_ticks_per_second() * (MS_DELAY)) / 1000))) {
					ticks_at_last_message = alt_nticks();
					if (start_transmit_A == 1){
						PERF_BEGIN(performance_name, 2);
						if(altera_avalon_mutex_trylock(mutex, value) == LOCK_SUCCESS) {
							if(message->flag == NO_MESSAGE) {
								//PERF_BEGIN(performance_name, 2);
								for (i = 0; i < 16; i++) {
									for (j = 0; j< 32; j++){
										message->A_buf[i][j] = A[i+16][j];
									}
								}
								message->flag = MESSAGE_WAITING_A_ELEMENT;
								start_transmit_A = 0;
								start_transmit_B = 1;
							}
							// Release the mutex
							altera_avalon_mutex_unlock(mutex);

						}
					}else if(start_transmit_B == 1){
						if(altera_avalon_mutex_trylock(mutex, value) == LOCK_SUCCESS) {
							if(message->flag == NO_MESSAGE) {
								for (i = 0;i < 32;i++){
									for (j = 0; j< 4;j++){
										message->B_buf[i][j] = B[i][j + B_column_count];
										//printf("%d ",message->B_buf[i][j]);
									}
									//printf("\n");
								}
								message->flag = MESSAGE_WAITING_B_ELEMENT;
								B_column_count += 4;
								if (B_column_count == 32) start_transmit_B = 0;

							}
							// Release the mutex
							altera_avalon_mutex_unlock(mutex);
						}
					}else if (B_column_count == 32){
						PERF_END(performance_name, 2);
						if(altera_avalon_mutex_trylock(mutex, value) == LOCK_SUCCESS) {
							if(message->flag == NO_MESSAGE) {
								PERF_BEGIN(performance_name, 3);
								PERF_BEGIN(performance_name, 4);
								message->flag = MESSAGE_START_CALC;
								ready = 0;
								calc = 1;
							}
							// Release the mutex
							altera_avalon_mutex_unlock(mutex);

						}
					}
				}
			}

			// Check the message buffer
			// and if there's a message waiting with the correct flag, print it to stdout.

			if(message->flag == MESSAGE_WAITING_DATA) {
				ready = 1;
				start_transmit_A = 1;
				message->flag = NO_MESSAGE;
			}
			if(message->flag == MESSAGE_RESULT_READY) {
				PERF_END(performance_name, 4);
				PERF_BEGIN(performance_name, 5);
				for (i = 0; i < 16; i++) {
					//printf("Row %d from CPU2 \n", i);
					for (j = 0; j< 32; j++){
						C[i+16][j] = message->A_buf[i][j];
					}
					//printf("\n");
				}
				PERF_END(performance_name, 5);
				PERF_END(performance_name, 6);
				//PERF_BEGIN(performance_name, 6);
				for (i = 0; i < 32; i++) {
					//printf("C Row %d\n", i);
					for (j = 0; j< 32; j++){
						printf("%d ", C[i][j]);
					}
					printf("\n");
				}

				done_calculation = 1;
				message->flag = NO_MESSAGE;
				PERF_STOP_MEASURING(performance_name);

				printf("Array Generation PC: %d\n", perf_get_section_time(performance_name,1));
				printf("Data Transfer from CPU1 to CPU2 PC: %d\n", perf_get_section_time(performance_name,2));
				printf("Array Calculation on CPU1 PC: %d\n", perf_get_section_time(performance_name,3));
				printf("Array Calculation on CPU2 PC: %d\n", perf_get_section_time(performance_name,4));
				printf("Data Transfer from CPU2 to CPU1 PC: %d\n", perf_get_section_time(performance_name,5));
				printf("The counter from the start array generation until C is ready to be printed PC: %d\n", perf_get_section_time(performance_name,6));
				printf("\nPress either of the buttons connected to CPU1 to start generation\n");
			}
		}
	}

	return(0);
}
