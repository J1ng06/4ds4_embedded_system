// Copyright by Adam Kinsman, Henry Ko and Nicola Nicolici
// Developed for the Embedded Systems course (COE4DS4)
// Department of Electrical and Computer Engineering
// McMaster University
// Ontario, Canada

#include "define.h"

// For the performance counter
void *performance_name = PERFORMANCE_COUNTER_0_BASE;

// Definition of semaphore for PBs
OS_EVENT *PBSemaphore[4];

// Definition of mailboxes
OS_EVENT *MboxGenArrayStart[2];

OS_EVENT *MboxTopLeftStart[2];
OS_EVENT *MboxBottomLeftStart[2];
OS_EVENT *MboxTopRightStart[2];
OS_EVENT *MboxBottomRightStart[2];

OS_EVENT *MboxTopLeftDone;
OS_EVENT *MboxBottomLeftDone;
OS_EVENT *MboxTopRightDone;
OS_EVENT *MboxBottomRightDone;

OS_EVENT *MboxMerge;

// memory partition
OS_MEM	*MemoryPartition;

// Definition of task stacks
OS_STK	  initialize_task_stk[TASK_STACKSIZE];
OS_STK	  task_launcher_stk[TASK_STACKSIZE];
OS_STK	  sorting_stk[TASK_STACKSIZE];
OS_TCB	  sorting_tcb;

OS_STK	  gen_array_stk[2][TASK_STACKSIZE];
OS_TCB	  gen_array_tcb[2];
OS_STK	  find_min_stk[2][TASK_STACKSIZE];
OS_TCB	  find_min_tcb[2];
OS_STK	  find_max_stk[2][TASK_STACKSIZE];
OS_TCB	  find_max_tcb[2];
OS_STK	  find_min_max_stk[TASK_STACKSIZE];
OS_TCB	  find_min_max_tcb;

// The sorting task
// It has the highest priority
// But it initiates other tasks by posting a message in the corresponding mailboxes
// Then it wait for the result to be computed by monitoring other mailboxes
// In the mean time, it'll suspend itself to free up the processor
void sorting(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	int i,j;
	INT32S *data_array[2];

	while (1) {
		// Delay for 2 secs so that the message from this task will be displayed last
		// If not delay, since it has highest priority, the wait message for PB0 will be displayed first
		OSTimeDlyHMSM(0, 0, 2, 0);

		printf("Waiting for PB0 to calculate 32 x 32 matrices each with %d entries\n", ARRAY_SIZE);
		OSSemPend(PBSemaphore[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("Calculation started\n");

		// Get the memory block from memory partition, and pass that memory block to other task through mailboxes
		// to start data generation
		for (i = 0; i < 2; i++) {
			data_array[i] = OSMemGet(MemoryPartition, &return_code);
			alt_ucosii_check_return_code(return_code);
			
			return_code = OSMboxPost(MboxGenArrayStart[i], (void *)(data_array[i]));
			alt_ucosii_check_return_code(return_code);
		}

		// Start the performance counter
		PERF_START_MEASURING(performance_name);
		PERF_BEGIN(performance_name, 3);
		printf("-waiting for merge...\n");

		// Now wait for merge result
		OSMboxPend(MboxMerge, 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		PERF_STOP_MEASURING(performance_name);
		printf("Array Generations PC: %d\n", perf_get_section_time(performance_name,1));
		//printf("Array 1 Generation PC: %d\n", perf_get_section_time(performance_name,2));
		printf("Calculations PC: %d\n", perf_get_section_time(performance_name,2));
		printf("From random generation until C is ready to be printed PC: %d\n", perf_get_section_time(performance_name,3));
		for (i = 0; i < 2; i++) {
			return_code = OSMemPut(MemoryPartition, (void *)data_array[i]);
			alt_ucosii_check_return_code(return_code);
		}
	}
}

// gen_array_0 task
// It randomly generates numbers in the range of 0-65535 (16 bits)
// And stores them in the data array obtained from the mailbox
void gen_array_0(void* pdata) {
	INT32S *data_array;
	INT8U return_code = OS_NO_ERR;
	int i;
	int switches;

	while (1) {

		//printf("gen_array_0 wait for start\n");
		data_array = (INT32S *)OSMboxPend(MboxGenArrayStart[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		//printf("gen_array_0 started (%p)\n", data_array);

		// Get the seed from the switches
		switches = IORD(SWITCH_I_BASE, 0);

		srand(switches);

		// Start generation
		PERF_BEGIN(performance_name, 1);
		for (i = 0; i < ARRAY_SIZE; i++) {
			data_array[i] = (rand() % 20001) - 10000;
		}

		//printf("gen_array_0 done (min: %d)(max: %d)\n", min_value, max_value);
		
		// When data generation is finished, the data array is posted to
		// two different mailboxes, so that the two tasks for finding
		// the min and max values in the array will be initiated
		return_code = OSMboxPost(MboxTopLeftStart[0], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		return_code = OSMboxPost(MboxBottomLeftStart[0], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		return_code = OSMboxPost(MboxTopRightStart[0], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		return_code = OSMboxPost(MboxBottomRightStart[0], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// gen_array_1 task
// It randomly generates numbers in the range of 0-65535 (16 bits)
// And stores them in the data array obtained from the mailbox
void gen_array_1(void* pdata) {
	INT32S *data_array;
	INT8U return_code = OS_NO_ERR;
	int i;
	int switches;

	while (1) {
		//printf("gen_array_1 wait for start\n");
		data_array = (INT32S *)OSMboxPend(MboxGenArrayStart[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		switches = IORD(SWITCH_I_BASE, 0);

		srand(~switches);
		//PERF_BEGIN(performance_name, 2);
		// Start generation
		for (i = 0; i < ARRAY_SIZE; i++) {
			data_array[i] = (rand() % 801) - 400;
		}
		PERF_END(performance_name, 1);
		//printf("gen_array_1 done (min: %d)(max: %d)\n", min_value, max_value);

		// When data generation is finished, the data array is posted to
		// two different mailboxes, so that the two tasks for finding
		// the min and max values in the array will be initiated
		return_code = OSMboxPost(MboxTopLeftStart[1], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		return_code = OSMboxPost(MboxBottomLeftStart[1], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		return_code = OSMboxPost(MboxTopRightStart[1], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);

		return_code = OSMboxPost(MboxBottomRightStart[1], (void *)(data_array));
		alt_ucosii_check_return_code(return_code);
		PERF_BEGIN(performance_name, 2);
		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// find_min_0 task
// It obtains the data array from the mailbox
// and then find the min value in the array
void top_left(void* pdata) {
	INT32S *data_array_0, *data_array_1, sum = 0;
	INT8U return_code = OS_NO_ERR;
	int i,j,k;
	int result[16][16];

	while (1) {
		//printf("Top left wait for start\n");
		data_array_0 = (INT32S *)OSMboxPend(MboxTopLeftStart[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		data_array_1 = (INT32S *)OSMboxPend(MboxTopLeftStart[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		//printf("Top left using (%p) and (%p)\n", data_array_0, data_array_1 );

		// Start performance counter
		//PERF_BEGIN(performance_name, 1);
		sum = 0;
		for (i = 0;i < 16; i++){
			for (j = 0; j < 16; j++){
				for (k = 0; k < 32; k++){
					sum += data_array_0[i*32 + k] * data_array_1[j + 32*k];
					//printf("%d \n",sum);
				}
				result[i][j] = sum;
				sum = 0;
			}
		}

		// Post the min value to the mailbox for other task
		return_code = OSMboxPost(MboxTopLeftDone, (void *)(&result));
		alt_ucosii_check_return_code(return_code);

		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// find_max_0 task
// It obtains the data array from the mailbox
// and then find the min value in the array
void bottom_left(void* pdata) {
	INT32S *data_array_0, *data_array_1;
	INT8U return_code = OS_NO_ERR;
	int i,j,k, sum = 0;
	int result[16][16];

	while (1) {
		//printf("Bottom left wait for start\n");

		data_array_0 = (INT32S *)OSMboxPend(MboxBottomLeftStart[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		data_array_1 = (INT32S *)OSMboxPend(MboxBottomLeftStart[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		//printf("Bottom left using (%p) and (%p)\n", data_array_0, data_array_1);

		// Start performance counter
		//PERF_BEGIN(performance_name, 1);
		sum = 0;
		for (i = 16;i < 32; i++){
			for (j = 0; j < 16; j++){
				for (k = 0; k < 32; k++){
					sum += data_array_0[i*32 + k] * data_array_1[j + 32*k];
					//printf("%d \n",sum);
				}
				result[i-16][j] = sum;
				sum = 0;
			}
		}


		//printf("Bottom left done (%d)\n", max_value);

		// Post the max value to the mailbox for other task
		return_code = OSMboxPost(MboxBottomLeftDone, (void *)(&result));
		alt_ucosii_check_return_code(return_code);

		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// find_min_1 task
// It obtains the data array from the mailbox
// and then find the min value in the array
void top_right(void* pdata) {
	INT32S *data_array_0, *data_array_1;
	INT8U return_code = OS_NO_ERR;
	int i,j,k, sum = 0;
	int result[16][16];
	while (1) {
		//printf("Top right wait for start\n");

		data_array_0 = (INT32S *)OSMboxPend(MboxTopRightStart[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		data_array_1 = (INT32S *)OSMboxPend(MboxTopRightStart[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		//printf("Top right using (%p) and (%p)\n", data_array_0, data_array_1);
		sum = 0;
		for (i = 0;i < 16; i++){
			for (j = 16; j < 32; j++){
				for (k = 0; k < 32; k++){
					sum += data_array_0[i*32 + k] * data_array_1[j + 32*k];
					//printf("%d \n",sum);
				}
				result[i][j-16] = sum;
				sum = 0;
			}
		}
//		for (i = 0;i < 16; i++){
//			for (j = 0; j < 16; j++){
//				printf("%d ",result[i][j]);
//				OSTimeDlyHMSM(0, 0, 0, 1);
//			}
//			printf("\n");
//		}
		// Start performance counter
		//PERF_BEGIN(performance_name, 2);
//		for (i = 0; i < ARRAY_SIZE; i++) {
//			if (data_array[i] < min_value) min_value = data_array[i];
//		}
		// Stop performance counter
		//PERF_END(performance_name, 2);

		//printf("Top right done (%d)\n", min_value);

		// Post the min value to the mailbox for other task
		return_code = OSMboxPost(MboxTopRightDone, (void *)(&result));
		alt_ucosii_check_return_code(return_code);

		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// bottom_right task
// It obtains the data array from the mailbox
// and then find the min value in the array
void bottom_right(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	INT32S *data_array_0,*data_array_1;
	int i,j,k, sum = 0;
	int result[16][16];

	while (1) {
		//printf("Bottom right wait for start\n");

		data_array_0 = (INT32S *)OSMboxPend(MboxBottomRightStart[0], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		data_array_1 = (INT32S *)OSMboxPend(MboxBottomRightStart[1], 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		//printf("Bottom right using (%p) and (%p)\n", data_array_0, data_array_1);

		// Start performance counter
		//PERF_BEGIN(performance_name, 2);
		sum = 0;
		for (i = 16;i < 32; i++){
			for (j = 16; j < 32; j++){
				for (k = 0; k < 32; k++){
					sum += data_array_0[i*32 + k] * data_array_1[j + 32*k];
					//printf("%d \n",sum);
				}
				result[i-16][j-16] = sum;
				sum = 0;
			}
		}

//		for (i = 0;i < 16; i++){
//			for (j = 0; j < 16; j++){
//				printf("%d ",result[i][j]);
//				OSTimeDlyHMSM(0, 0, 0, 1);
//			}
//			printf("\n");
//		}
		/*for (i = 0; i < ARRAY_SIZE; i++) {
			if (data_array[i] > max_value) max_value = data_array[i];
		}
		*/
		// Stop performance counter
		//PERF_END(performance_name, 2);

		//printf("Bottom right done (%d)\n", max_value);

		// Post the max value to the mailbox for other task
		return_code = OSMboxPost(MboxBottomRightDone, (void *)(&result));
		alt_ucosii_check_return_code(return_code);

		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// find_min_max task
// It obtains the four min and max values for the two data arrays from the mailboxes
// and then find the global min and max values in the arrays
// It post the results into the same mailbox at the end
void merge(void* pdata) {
	INT8U return_code = OS_NO_ERR;
	INT32S *result_TL, *result_BL, *result_TR, *result_BR;
	int i,j;
	int result[32][32];

	while (1) {
		printf("merge wait for start\n");
		result_TL = (INT32S *)OSMboxPend(MboxTopLeftDone, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		result_BL= (INT32S *)OSMboxPend(MboxBottomLeftDone, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		result_TR = (INT32S *)OSMboxPend(MboxTopRightDone, 0, &return_code);
		alt_ucosii_check_return_code(return_code);
		result_BR = (INT32S *)OSMboxPend(MboxBottomRightDone, 0, &return_code);
		alt_ucosii_check_return_code(return_code);

		printf("merge started\n");

		// Start performance counter
		//PERF_BEGIN(performance_name, 3);


		// Stop performance counter
		//PERF_END(performance_name, 3);

		//printf("find_min_max done\n");
		
		// Post the min and max value to the same mailbox
//		return_code = OSMboxPost(MboxMerge, (void *)(&min_value));
//		alt_ucosii_check_return_code(return_code);
//		return_code = OSMboxPost(MboxMerge, (void *)(&max_value));
//		alt_ucosii_check_return_code(return_code);
		for (i = 0; i < 32; i++) {
			for (j = 0; j < 32; j++) {
				if (i < 16 && j < 16) {
					result[i][j] = result_TL[16*i + j];
				}
				if (i < 16 && j >= 16) {
					result[i][j] = result_TR[16*i + (j - 16)];
				}
				if (i >= 16 && j < 16) {
					result[i][j] = result_BL[16*(i - 16) + j];
				}
				if (i >= 16 && j >= 16){
					result[i][j] = result_BR[16*(i - 16) + (j - 16)];
				}
			}
		}
		PERF_END(performance_name, 2);
		PERF_END(performance_name, 3);

		for (i = 0; i < 32; i++) {
			for (j = 0; j < 32; j++) {
				printf("%d ",result[i][j]);
			}
			printf("\n");
			OSTimeDlyHMSM(0, 0, 0, 100);
		}
		return_code = OSMboxPost(MboxMerge, (void *)(&result));
		alt_ucosii_check_return_code(return_code);

		OSTimeDlyHMSM(0, 0, 1, 0);
	}
}

// Task launcher
// It creates all the custom tasks
// And then it deletes itself
void task_launcher(void *pdata) {
	INT8U return_code = OS_NO_ERR;

	#if OS_CRITICAL_METHOD == 3
			OS_CPU_SR cpu_sr;
	#endif

	printf("Starting task launcher...\n");
	while (1) {
		OS_ENTER_CRITICAL();
		printf("Creating tasks...\n");

		return_code = OSTaskCreateExt(sorting,
			NULL,
			(void *)&sorting_stk[TASK_STACKSIZE-1],
			SORTING_PRIORITY,
			SORTING_PRIORITY,
			&sorting_stk,
			TASK_STACKSIZE,
			&sorting_tcb,
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(gen_array_0,
			NULL,
			(void *)&gen_array_stk[0][TASK_STACKSIZE-1],
			GEN_ARRAY_0_PRIORITY,
			GEN_ARRAY_0_PRIORITY,
			&gen_array_stk[0][0],
			TASK_STACKSIZE,
			&gen_array_tcb[0],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(gen_array_1,
			NULL,
			(void *)&gen_array_stk[1][TASK_STACKSIZE-1],
			GEN_ARRAY_1_PRIORITY,
			GEN_ARRAY_1_PRIORITY,
			&gen_array_stk[1][0],
			TASK_STACKSIZE,
			&gen_array_tcb[1],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(top_left,
			NULL,
			(void *)&find_min_stk[0][TASK_STACKSIZE-1],
			TOP_LEFT_PRIORITY,
			TOP_LEFT_PRIORITY,
			&find_min_stk[0][0],
			TASK_STACKSIZE,
			&find_min_tcb[0],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(bottom_left,
			NULL,
			(void *)&find_max_stk[0][TASK_STACKSIZE-1],
			BOTTOM_LEFT_PRIORITY,
			BOTTOM_LEFT_PRIORITY,
			&find_max_stk[0][0],
			TASK_STACKSIZE,
			&find_max_tcb[0],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(top_right,
			NULL,
			(void *)&find_min_stk[1][TASK_STACKSIZE-1],
			TOP_RIGHT_PRIORITY,
			TOP_RIGHT_PRIORITY,
			&find_min_stk[1][0],
			TASK_STACKSIZE,
			&find_min_tcb[1],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(bottom_right,
			NULL,
			(void *)&find_max_stk[1][TASK_STACKSIZE-1],
			BOTTOM_RIGHT_PRIORITY,
			BOTTOM_RIGHT_PRIORITY,
			&find_max_stk[1][0],
			TASK_STACKSIZE,
			&find_max_tcb[1],
			0);
		alt_ucosii_check_return_code(return_code);

		return_code = OSTaskCreateExt(merge,
			NULL,
			(void *)&find_min_max_stk[TASK_STACKSIZE-1],
			FIND_MIN_MAX_PRIORITY,
			FIND_MIN_MAX_PRIORITY,
			&find_min_max_stk[0],
			TASK_STACKSIZE,
			&find_min_max_tcb,
			0);
		alt_ucosii_check_return_code(return_code);

		printf("Finish creating tasks...\n");

		printf("\n");
		OSTimeDlyHMSM(0, 0, 1, 0);

		return_code = OSTaskDel(OS_PRIO_SELF);
		alt_ucosii_check_return_code(return_code);

		OS_EXIT_CRITICAL();
	}
}
